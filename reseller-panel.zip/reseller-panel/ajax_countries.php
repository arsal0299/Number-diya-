<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/numberpanel_api.php';
require_login();

header('Content-Type: application/json');
$service = trim($_GET['service'] ?? '');
if ($service === '') {
    echo json_encode(['success' => false, 'countries' => []]);
    exit;
}
echo json_encode(np_countries($service));
