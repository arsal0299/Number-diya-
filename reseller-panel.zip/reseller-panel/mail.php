<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/numberpanel_api.php';
$user = require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'generate') {
    csrf_verify('mail.php');
    $username = trim($_POST['username'] ?? '');
    $result = np_mail_generate($username);
    if (!empty($result['success']) && !empty($result['mail']['address'])) {
        $stmt = safe_prepare(db(), 'INSERT INTO mailboxes (user_id, address, token) VALUES (?, ?, ?)');
        $token = $result['mail']['token'] ?? '';
        mysqli_stmt_bind_param($stmt, 'iss', $user['id'], $result['mail']['address'], $token);
        mysqli_stmt_execute($stmt);
        flash('success', 'Mailbox created: ' . $result['mail']['address']);
    } else {
        flash('error', 'Could not generate mailbox: ' . ($result['message'] ?? 'unknown error'));
    }
    redirect('mail.php');
}

$mailStmt = safe_prepare(db(), 'SELECT * FROM mailboxes WHERE user_id = ? ORDER BY created_at DESC');
mysqli_stmt_bind_param($mailStmt, 'i', $user['id']);
mysqli_stmt_execute($mailStmt);
$mailboxes = mysqli_fetch_all(mysqli_stmt_get_result($mailStmt), MYSQLI_ASSOC);

$viewMessages = [];
$viewAddress = trim($_GET['address'] ?? '');
if ($viewAddress !== '') {
    $owns = array_filter($mailboxes, fn($m) => $m['address'] === $viewAddress);
    if ($owns) {
        $msgResult = np_mail_messages($viewAddress);
        $viewMessages = $msgResult['messages'] ?? [];
    }
}

$pageTitle = 'Temporary Mail';
require_once __DIR__ . '/includes/header.php';
?>
<div class="page-head">
  <h1>Temporary mail</h1>
  <p>Generate a disposable inbox for signups and verification.</p>
</div>

<div class="grid grid-2" style="margin-bottom:32px;">
  <div class="card table-scroll">
    <h3>Generate a mailbox</h3>
    <form method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="generate">
      <label>Preferred username (optional)</label>
      <input type="text" name="username" placeholder="e.g. demo">
      <button type="submit">Generate mailbox</button>
    </form>
  </div>
  <div class="card table-scroll">
    <h3>Your mailboxes</h3>
    <?php if (empty($mailboxes)): ?>
      <div class="empty">No mailboxes yet.</div>
    <?php else: ?>
      <div class="feed">
      <?php foreach ($mailboxes as $m): ?>
        <div class="feed-row" style="justify-content:space-between;">
          <span><?= clean($m['address']) ?></span>
          <a href="mail.php?address=<?= urlencode($m['address']) ?>" style="color:var(--amber)">View inbox →</a>
        </div>
      <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php if ($viewAddress !== ''): ?>
<div class="page-head"><h1>Inbox — <?= clean($viewAddress) ?></h1></div>
<div class="card table-scroll">
  <?php if (empty($viewMessages)): ?>
    <div class="empty">No messages yet. Refresh this page after sending a test email.</div>
  <?php else: ?>
    <table>
      <tr><th>From</th><th>Subject</th><th>Received</th></tr>
      <?php foreach ($viewMessages as $msg): ?>
      <tr>
        <td><?= clean($msg['from'] ?? '—') ?></td>
        <td><?= clean($msg['subject'] ?? '—') ?></td>
        <td><?= clean($msg['received_at'] ?? '—') ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  <?php endif; ?>
</div>
<?php endif; ?>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
