<?php
require_once __DIR__ . '/includes/functions.php';
$user = require_login();

$txStmt = safe_prepare(db(), 'SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50');
mysqli_stmt_bind_param($txStmt, 'i', $user['id']);
mysqli_stmt_execute($txStmt);
$transactions = mysqli_fetch_all(mysqli_stmt_get_result($txStmt), MYSQLI_ASSOC);

$reqStmt = safe_prepare(db(), 'SELECT * FROM number_requests WHERE user_id = ? ORDER BY requested_at DESC LIMIT 50');
mysqli_stmt_bind_param($reqStmt, 'i', $user['id']);
mysqli_stmt_execute($reqStmt);
$requests = mysqli_fetch_all(mysqli_stmt_get_result($reqStmt), MYSQLI_ASSOC);

$pageTitle = 'History';
require_once __DIR__ . '/includes/header.php';
?>
<div class="page-head"><h1>Wallet history</h1></div>
<div class="card table-scroll" style="margin-bottom:32px;">
  <?php if (empty($transactions)): ?>
    <div class="empty">No transactions yet.</div>
  <?php else: ?>
    <table>
      <tr><th>Date</th><th>Type</th><th>Amount</th><th>Description</th></tr>
      <?php foreach ($transactions as $t): ?>
      <tr>
        <td><?= clean(date('d M, H:i', strtotime($t['created_at']))) ?></td>
        <td><span class="badge <?= $t['type'] === 'credit' ? 'active' : 'released' ?>"><?= clean($t['type']) ?></span></td>
        <td class="mono"><?= ($t['type'] === 'credit' ? '+' : '-') . 'Rs ' . number_format((float)$t['amount'], 2) ?></td>
        <td><?= clean($t['description']) ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  <?php endif; ?>
</div>

<div class="page-head"><h1>Number requests</h1></div>
<div class="card table-scroll">
  <?php if (empty($requests)): ?>
    <div class="empty">No number requests yet.</div>
  <?php else: ?>
    <table>
      <tr><th>Number</th><th>Service</th><th>Country</th><th>OTP</th><th>Status</th><th>Requested</th></tr>
      <?php foreach ($requests as $r): ?>
      <tr>
        <td class="mono"><?= clean($r['number']) ?></td>
        <td><?= clean($r['service']) ?></td>
        <td><?= clean($r['country']) ?></td>
        <td class="mono"><?= $r['otp_code'] ? clean($r['otp_code']) : '—' ?></td>
        <td><span class="badge <?= clean($r['status']) ?>"><?= clean($r['status']) ?></span></td>
        <td><?= clean(date('d M, H:i', strtotime($r['requested_at']))) ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
