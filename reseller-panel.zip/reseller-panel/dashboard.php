<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/numberpanel_api.php';
$user = require_login();

// Auto-expire any numbers that timed out waiting for an OTP (releases the hold, no charge).
expire_pending_numbers();
$user = current_user(); // reload in case a hold on this user was just released

$holdMinutes = (int) get_setting('number_hold_minutes', '20');
$countryStatus = get_setting('country_status', '');

// ── Handle: request a new number ──────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'request') {
    csrf_verify('dashboard.php');
    $service = trim($_POST['service'] ?? '');
    $country = trim($_POST['country'] ?? '');
    $price = get_service_price($service);

    if ($service === '' || $country === '') {
        flash('error', 'Please choose a service and a country.');
    } elseif (wallet_available($user) < $price) {
        flash('error', 'Insufficient balance. Please top up your wallet.');
    } else {
        $result = np_request_number($service, $country);
        if (!empty($result['success']) && !empty($result['number'])) {
            if (!wallet_hold($user['id'], $price)) {
                np_release_number($result['number']);
                flash('error', 'Insufficient balance. Please top up your wallet.');
            } else {
                $expiresAt = date('Y-m-d H:i:s', time() + $holdMinutes * 60);
                $stmt = safe_prepare(db(), 'INSERT INTO number_requests (user_id, service, country, number, cost, hold_amount, expires_at, status) VALUES (?, ?, ?, ?, ?, ?, ?, "pending")');
                mysqli_stmt_bind_param($stmt, 'isssdds', $user['id'], $service, $country, $result['number'], $price, $price, $expiresAt);
                mysqli_stmt_execute($stmt);
                flash('success', "Number requested: {$result['number']} — Rs " . number_format($price, 2) . " is held (not charged) until an OTP arrives. Auto-refunded if none arrives within {$holdMinutes} minutes.");
            }
        } else {
            flash('error', 'Provider error: ' . ($result['message'] ?? 'no numbers available right now.'));
        }
    }
    redirect('dashboard.php');
}

// ── Handle: release a number ────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'release') {
    csrf_verify('dashboard.php');
    $reqId = (int) ($_POST['request_id'] ?? 0);
    $stmt = safe_prepare(db(), 'SELECT * FROM number_requests WHERE id = ? AND user_id = ? LIMIT 1');
    mysqli_stmt_bind_param($stmt, 'ii', $reqId, $user['id']);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    if ($row && in_array($row['status'], ['active', 'pending'], true)) {
        np_release_number($row['number']);
        if ($row['status'] === 'pending') {
            wallet_release_hold($user['id'], (float) $row['hold_amount']);
        }
        $upd = safe_prepare(db(), "UPDATE number_requests SET status='released', released_at=NOW() WHERE id = ?");
        mysqli_stmt_bind_param($upd, 'i', $reqId);
        mysqli_stmt_execute($upd);
        flash('success', $row['status'] === 'pending' ? 'Number released — your held balance was refunded.' : 'Number released.');
    }
    redirect('dashboard.php');
}

// ── Handle: check for OTP (AJAX-free simple refresh) ─────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'check_otp') {
    csrf_verify('dashboard.php');
    $reqId = (int) ($_POST['request_id'] ?? 0);
    $stmt = safe_prepare(db(), 'SELECT * FROM number_requests WHERE id = ? AND user_id = ? LIMIT 1');
    mysqli_stmt_bind_param($stmt, 'ii', $reqId, $user['id']);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    if ($row && $row['status'] === 'pending') {
        $otpResult = np_latest_otp($row['number']);
        if (!empty($otpResult['has_otp']) && !empty($otpResult['otp_code'])) {
            $charged = wallet_finalize_hold($user['id'], (float) $row['hold_amount'], "Number verified: {$row['service']}/{$row['country']}");
            $upd = safe_prepare(db(), "UPDATE number_requests SET otp_code = ?, otp_received_at = NOW(), status = 'active' WHERE id = ?");
            mysqli_stmt_bind_param($upd, 'si', $otpResult['otp_code'], $reqId);
            mysqli_stmt_execute($upd);
            flash('success', 'OTP received: ' . $otpResult['otp_code'] . ($charged ? ' — Rs ' . number_format((float)$row['hold_amount'], 2) . ' charged.' : ''));
        } elseif (!empty($row['expires_at']) && strtotime($row['expires_at']) <= time()) {
            np_release_number($row['number']);
            wallet_release_hold($user['id'], (float) $row['hold_amount']);
            $upd = safe_prepare(db(), "UPDATE number_requests SET status = 'expired', released_at = NOW() WHERE id = ?");
            mysqli_stmt_bind_param($upd, 'i', $reqId);
            mysqli_stmt_execute($upd);
            flash('error', 'No OTP arrived in time — the number expired and your balance was refunded.');
        } else {
            flash('error', 'No OTP yet — try again in a few seconds.');
        }
    }
    redirect('dashboard.php');
}

// ── Load data for the page ────────────────────────────────────
$servicesResp = np_services();
$services = $servicesResp['services'] ?? [];

$activeStmt = safe_prepare(db(), "SELECT * FROM number_requests WHERE user_id = ? AND status IN ('active','pending') ORDER BY requested_at DESC");
mysqli_stmt_bind_param($activeStmt, 'i', $user['id']);
mysqli_stmt_execute($activeStmt);
$activeNumbers = mysqli_fetch_all(mysqli_stmt_get_result($activeStmt), MYSQLI_ASSOC);

$pageTitle = 'Numbers — Dashboard';
require_once __DIR__ . '/includes/header.php';
?>
<div class="page-head">
  <h1>Get a number</h1>
  <p>wallet balance Rs <?= number_format((float)$user['wallet_balance'], 2) ?> · available to spend Rs <?= number_format(wallet_available($user), 2) ?><?= (float)($user['wallet_hold'] ?? 0) > 0 ? ' (Rs ' . number_format((float)$user['wallet_hold'], 2) . ' held on pending numbers)' : '' ?></p>
</div>

<?php if ($countryStatus !== ''): ?>
<div class="alert" style="background:rgba(203,161,53,0.08); border-color:var(--gold); color:var(--gold-bright);">
  <strong>Status:</strong> <?= clean($countryStatus) ?>
</div>
<?php endif; ?>

<div class="grid grid-2" style="margin-bottom:32px;">
  <div class="card">
    <h3>Request a virtual number</h3>
    <form method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="request">
      <label>Service</label>
      <select name="service" id="serviceSelect" required onchange="loadCountries()">
        <option value="">Select a service…</option>
        <?php foreach ($services as $s): ?>
          <option value="<?= clean($s['name']) ?>"><?= clean($s['name']) ?> — Rs <?= number_format(get_service_price($s['name']), 2) ?> (<?= (int)($s['count'] ?? 0) ?> available)</option>
        <?php endforeach; ?>
      </select>
      <label>Country</label>
      <select name="country" id="countrySelect" required>
        <option value="">Select a service first…</option>
      </select>
      <button type="submit">Request number</button>
    </form>
  </div>
  <div class="card">
    <h3>How it works</h3>
    <div class="feed">
      <div class="feed-row">1 · Pick a service &amp; country</div>
      <div class="feed-row">2 · Get a live number instantly — the price is <em>held</em>, not charged yet</div>
      <div class="feed-row">3 · Send it for verification, then check for the <span class="otp">OTP</span> below</div>
      <div class="feed-row">4 · Only charged once the OTP arrives — no OTP within <?= (int)$holdMinutes ?> min = automatic full refund</div>
    </div>
  </div>
</div>

<div class="page-head"><h1>Your numbers</h1></div>
<div class="card table-scroll">
  <?php if (empty($activeNumbers)): ?>
    <div class="empty">No active numbers yet — request one above.</div>
  <?php else: ?>
  <table>
    <tr><th>Number</th><th>Service</th><th>Country</th><th>Status</th><th>OTP</th><th>Expires</th><th></th></tr>
    <?php foreach ($activeNumbers as $n): ?>
    <tr>
      <td class="mono"><?= clean($n['number']) ?></td>
      <td><?= clean($n['service']) ?></td>
      <td><?= clean($n['country']) ?></td>
      <td><span class="badge <?= $n['status'] === 'active' ? 'active' : 'pending' ?>"><?= $n['status'] === 'active' ? 'Charged' : 'Waiting for OTP (held)' ?></span></td>
      <td class="mono" style="color:var(--amber)"><?= $n['otp_code'] ? clean($n['otp_code']) : '—' ?></td>
      <td class="mono"><?= $n['status'] === 'pending' && $n['expires_at'] ? '<span class="countdown" data-expires="' . clean($n['expires_at']) . '">--:--</span>' : '—' ?></td>
      <td style="white-space:nowrap;">
        <?php if ($n['status'] === 'pending'): ?>
        <form method="post" style="display:inline">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="check_otp">
          <input type="hidden" name="request_id" value="<?= (int)$n['id'] ?>">
          <button class="btn btn-outline btn-sm" type="submit">Check OTP</button>
        </form>
        <?php endif; ?>
        <form method="post" style="display:inline">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="release">
          <input type="hidden" name="request_id" value="<?= (int)$n['id'] ?>">
          <button class="btn btn-danger btn-sm" type="submit" onclick="return confirm('Release this number?')">Release</button>
        </form>
      </td>
    </tr>
    <?php endforeach; ?>
  </table>
  <?php endif; ?>
</div>

<script>
const servicesData = <?= json_encode($services) ?>;
<?php if (!empty(array_filter($activeNumbers, fn($n) => $n['status'] === 'pending'))): ?>
setTimeout(function () { window.location.reload(); }, 15000);
<?php endif; ?>

function loadCountries() {
  const service = document.getElementById('serviceSelect').value;
  const countrySelect = document.getElementById('countrySelect');
  countrySelect.innerHTML = '<option value="">Loading…</option>';
  if (!service) {
    countrySelect.innerHTML = '<option value="">Select a service first…</option>';
    return;
  }
  fetch('ajax_countries.php?service=' + encodeURIComponent(service))
    .then(r => r.json())
    .then(data => {
      const countries = data.countries || [];
      if (!countries.length) {
        countrySelect.innerHTML = '<option value="">No countries available</option>';
        return;
      }
      countrySelect.innerHTML = '<option value="">Select a country…</option>' +
        countries.map(c => `<option value="${c.name}">${c.name} (${c.count || 0} available)</option>`).join('');
    })
    .catch(() => { countrySelect.innerHTML = '<option value="">Could not load countries</option>'; });
}

</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
