<?php
/**
 * Hit this URL every 1–5 minutes with a free scheduler (InfinityFree's own
 * cron under "Cron Jobs" in the control panel, or an external one like
 * cron-job.org / uptimerobot.com) so pending numbers auto-refund on time
 * even if no user happens to have the site open.
 *
 * Example: https://yourdomain.com/cron/expire_numbers.php?key=YOUR_CRON_SECRET
 * Set YOUR_CRON_SECRET in Admin → Settings → Cron secret.
 */
require_once __DIR__ . '/../includes/functions.php';

$secret = get_setting('cron_secret', '');
if ($secret === '' || !hash_equals($secret, $_GET['key'] ?? '')) {
    http_response_code(403);
    echo 'Forbidden';
    exit;
}

expire_pending_numbers();
echo 'OK ' . date('Y-m-d H:i:s');
