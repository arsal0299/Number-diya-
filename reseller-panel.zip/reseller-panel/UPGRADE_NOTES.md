# What changed — read this before uploading

## 1. The bug (site crashing / 500 error when adding a number)
`dashboard.php` was inserting 5 values into `number_requests` but only gave
mysqli 4 type letters (`'issd'` for 5 variables). PHP 8's mysqli throws a
fatal error the instant that mismatch happens — that's exactly the 500 you
were seeing. Fixed as part of the full dashboard.php rewrite below.

## 2. Steps to upgrade a live/existing install
1. Upload all these files over your current ones (same folder structure).
2. In phpMyAdmin, open **schema_update_v3.sql** and run it (it only adds
   new columns/tables — safe on a live site). If one line errors with
   "duplicate column", that just means it's already applied — skip it and
   run the rest.
3. Go to **Admin → Settings** and fill in:
   - Payment method / account details (shown to users on the Top Up page)
   - Country/service status banner (shown on the user dashboard)
   - Support email (defaults to marslan0299@gmail.com)
   - Cron secret (random string)
4. Set up a scheduler to hit
   `https://yourdomain.com/cron/expire_numbers.php?key=YOUR_CRON_SECRET`
   every 1–5 minutes — InfinityFree's control panel has "Cron Jobs" for
   free accounts, or use a free external one like cron-job.org. This makes
   sure held balances get refunded on time even if nobody has the site
   open when a number times out. Numbers also self-expire the moment any
   user visits the dashboard, so this is a safety net, not a hard
   requirement.
5. Make sure `/uploads/payments/` is writable by PHP (InfinityFree gives
   folders 755 by default, which is fine).

## 3. New features
- **Hold-until-OTP wallet system**: requesting a number no longer charges
  the user immediately — it *holds* the price. The charge only happens
  once `Check OTP` finds a code. If no OTP arrives within the configured
  window (default 20 minutes, matching the provider's own number
  lifetime), the number auto-expires and the hold is released — nothing
  is charged.
- **Top Up / payment proof system** (`topup.php` for users,
  `comeon/payments.php` for admin): shows your payment account details,
  lets the user enter the amount and upload a screenshot, and creates a
  reviewable request. Admin can approve (auto-credits the wallet) or
  reject with a note — e.g. "This screenshot doesn't match our records" —
  which the user sees on their own Top Up page.
- **Per-service pricing**: set a custom price per app (WhatsApp, Telegram,
  etc.) in Admin → Settings; anything without a custom price falls back
  to the global default price.
- **Country/service status banner**: one text field in Admin → Settings
  that shows on every user's dashboard (e.g. "USA, UK working — number
  generation down elsewhere, Temp Mail OK").
- **Fuller admin user management**: Users list now shows numbers bought,
  OTPs received, and total spent per user, and each username links to a
  detail page with a per-app breakdown and full transaction history.
- **Security**: CSRF tokens on every form, login brute-force throttling
  (locks an identifier out for 15 minutes after repeated failures on both
  user and admin login), upload validation on payment screenshots
  (image-only, 5MB cap, random filenames, execution disabled in the
  uploads folder).
- **Mobile responsive pass**: collapsible nav on small screens, all wide
  tables scroll horizontally inside their card instead of breaking the
  layout, buttons/forms stack full-width on phones.

## 4. One important note
Your uploaded `config.php` has your live database password in plain text
inside it. That's normal for this kind of shared hosting (no environment
variables on InfinityFree), and `.htaccess` already blocks it from being
opened in a browser — but since you've now shared that file outside your
host, it's worth changing the database password from your InfinityFree
control panel and updating `config.php` with the new one, just to be safe.

## 5. Anything still missing?
Email marslan0299@gmail.com and it'll get added.
