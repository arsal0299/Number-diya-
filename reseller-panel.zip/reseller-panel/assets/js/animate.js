/* Numera — animations.js
   Vanilla JS only (no libraries) so pages stay fast on shared hosting.
   Handles: scroll-reveal on .reveal elements, and count-up on .stat-item .num. */

(function () {
    // ── Scroll reveal ──────────────────────────────────────
    var revealEls = document.querySelectorAll('.reveal');
    if ('IntersectionObserver' in window && revealEls.length) {
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    io.unobserve(entry.target);
                }
            });
        }, { threshold: 0.15 });
        revealEls.forEach(function (el) { io.observe(el); });
    } else {
        revealEls.forEach(function (el) { el.classList.add('is-visible'); });
    }

    // ── Count-up numbers (data-count="1500") ───────────────
    var counters = document.querySelectorAll('.num[data-count]');
    if ('IntersectionObserver' in window && counters.length) {
        var cio = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (!entry.isIntersecting) return;
                var el = entry.target;
                var target = parseFloat(el.getAttribute('data-count'));
                var suffix = el.getAttribute('data-suffix') || '';
                var duration = 1200;
                var start = null;
                function step(ts) {
                    if (!start) start = ts;
                    var progress = Math.min((ts - start) / duration, 1);
                    var eased = 1 - Math.pow(1 - progress, 3);
                    var value = Math.floor(eased * target);
                    el.textContent = value.toLocaleString() + suffix;
                    if (progress < 1) requestAnimationFrame(step);
                }
                requestAnimationFrame(step);
                cio.unobserve(el);
            });
        }, { threshold: 0.4 });
        counters.forEach(function (el) { cio.observe(el); });
    }
})();

// ── Flash alerts: auto-dismiss after a few seconds ─────────────
(function () {
    document.querySelectorAll('.alert').forEach(function (el) {
        setTimeout(function () {
            el.classList.add('fade-out');
            setTimeout(function () { el.remove(); }, 420);
        }, 5000);
    });
})();

// ── Live countdown for pending (held) numbers ───────────────────
// Any element with data-expires="2026-08-11 12:30:00" gets a live mm:ss countdown.
(function () {
    var els = document.querySelectorAll('[data-expires]');
    if (!els.length) return;
    function tick() {
        els.forEach(function (el) {
            var target = new Date(el.getAttribute('data-expires').replace(' ', 'T')).getTime();
            var diff = Math.max(0, Math.floor((target - Date.now()) / 1000));
            var m = Math.floor(diff / 60);
            var s = diff % 60;
            el.textContent = (diff <= 0) ? 'expired' : (m + ':' + (s < 10 ? '0' : '') + s);
            el.classList.toggle('countdown-warn', diff > 0 && diff <= 60);
        });
    }
    tick();
    setInterval(tick, 1000);
})();

// ── Sidebar drawer (shared by user + admin headers) ─────────────
(function () {
    var toggle = document.getElementById('sidebarToggle');
    var sidebar = document.getElementById('sidebar');
    var overlay = document.getElementById('sidebarOverlay');
    var closeBtn = document.getElementById('sidebarClose');
    if (!toggle || !sidebar) return;

    function openSidebar() {
        sidebar.classList.add('open');
        if (overlay) overlay.classList.add('open');
        document.body.classList.add('sidebar-locked');
        toggle.setAttribute('aria-expanded', 'true');
    }
    function closeSidebar() {
        sidebar.classList.remove('open');
        if (overlay) overlay.classList.remove('open');
        document.body.classList.remove('sidebar-locked');
        toggle.setAttribute('aria-expanded', 'false');
    }

    toggle.addEventListener('click', function () {
        sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
    });
    if (closeBtn) closeBtn.addEventListener('click', closeSidebar);
    if (overlay) overlay.addEventListener('click', closeSidebar);
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') closeSidebar();
    });
})();
