<?php
require_once __DIR__ . '/includes/functions.php';
$user = current_user();
$siteName = get_setting('site_name', 'Numera');
$price = (float) get_setting('price_per_number', '5.00');

$servicesResp = [];
$serviceCount = 0;
try {
    require_once __DIR__ . '/includes/numberpanel_api.php';
    $servicesResp = np_services();
    if (!empty($servicesResp['services'])) {
        foreach ($servicesResp['services'] as $s) { $serviceCount += (int) ($s['count'] ?? 0); }
    }
} catch (Exception $e) { /* landing page still renders fine without live stats */ }

$pageTitle = "$siteName — Premium Virtual Numbers, OTP & Temporary Mail";
$pageDescription = "Instant virtual phone numbers, real-time OTP delivery and disposable email inboxes — a premium, reliable platform for verification at scale.";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= clean($pageTitle) ?></title>
<meta name="description" content="<?= clean($pageDescription) ?>">
<meta name="robots" content="index, follow">
<meta property="og:title" content="<?= clean($pageTitle) ?>">
<meta property="og:description" content="<?= clean($pageDescription) ?>">
<meta property="og:type" content="website">
<meta name="theme-color" content="#0A0E17">
<link rel="canonical" href="<?= clean(SITE_URL) ?>/">
<link rel="icon" href="assets/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="assets/css/style.css">
<script type="application/ld+json">
{"@context":"https://schema.org","@type":"Organization","name":"<?= clean($siteName) ?>","url":"<?= clean(SITE_URL) ?>"}
</script>
</head>
<body>

<div class="topbar">
  <div class="topbar-inner">
    <div class="brand">
      <?php $landingLogo = site_logo_url(); if ($landingLogo): ?><img src="<?= clean($landingLogo) ?>" alt="<?= clean($siteName) ?>" class="logo-img">
      <?php else: ?><span class="dot"></span><?= clean($siteName) ?><?php endif; ?>
    </div>
    <div class="nav-links">
      <a href="#how-it-works">How it works</a>
      <a href="#features">Features</a>
      <a href="#pricing">Pricing</a>
      <?php if ($user): ?>
        <a href="dashboard.php" class="btn btn-sm">Go to dashboard</a>
      <?php else: ?>
        <a href="auth/login.php">Log in</a>
        <a href="auth/register.php" class="btn btn-sm">Get started</a>
      <?php endif; ?>
    </div>
  </div>
</div>

<section class="hero">
  <div class="hero-glow" aria-hidden="true"></div>
  <div class="wrap">
    <div class="eyebrow reveal" style="justify-content:center;">Verification, handled</div>
    <h1 class="reveal reveal-delay-1">Instant numbers.<br>Real OTPs. <span class="gold-text">Zero waiting.</span></h1>
    <p class="lead reveal reveal-delay-2">
      <?= clean($siteName) ?> gives you on-demand virtual phone numbers and disposable inboxes for
      verification — backed by a live provider network, delivered through one clean dashboard.
    </p>
    <div class="hero-ctas reveal reveal-delay-3">
      <a href="<?= $user ? 'dashboard.php' : 'auth/register.php' ?>" class="btn">Create your account</a>
      <a href="#how-it-works" class="btn btn-outline">See how it works</a>
    </div>

    <div class="stat-ticker reveal reveal-delay-3">
      <div class="stat-item">
        <div class="num" data-count="<?= max($serviceCount, 1500) ?>">0</div>
        <div class="label">Numbers available now</div>
      </div>
      <div class="stat-item">
        <div class="num" data-count="20" data-suffix="+">0</div>
        <div class="label">Supported services</div>
      </div>
      <div class="stat-item">
        <div class="num" data-count="99" data-suffix="%">0</div>
        <div class="label">Delivery uptime</div>
      </div>
    </div>
  </div>
</section>

<section class="section" id="how-it-works">
  <div class="wrap">
    <div class="section-head reveal">
      <div class="eyebrow" style="justify-content:center;">Process</div>
      <h2 class="section-title thread">How it works</h2>
      <p>Three steps between you and a verified account.</p>
    </div>
    <div class="steps">
      <div class="step reveal">
        <span class="step-num">01</span>
        <h4>Fund your wallet</h4>
        <p>Top up your balance — our team credits it manually within minutes of your request.</p>
      </div>
      <div class="step reveal reveal-delay-1">
        <span class="step-num">02</span>
        <h4>Request a number</h4>
        <p>Pick a service and country, and get a live, ready-to-use number instantly.</p>
      </div>
      <div class="step reveal reveal-delay-2">
        <span class="step-num">03</span>
        <h4>Receive your OTP</h4>
        <p>Check the dashboard — codes typically land within seconds of being sent.</p>
      </div>
    </div>
  </div>
</section>

<section class="section" id="features">
  <div class="wrap">
    <div class="section-head reveal">
      <div class="eyebrow" style="justify-content:center;">Platform</div>
      <h2 class="section-title thread">Built for reliability</h2>
      <p>Everything you need for verification workflows, in one account.</p>
    </div>
    <div class="feature-grid">
      <div class="feature reveal">
        <div class="icon">&#9670;</div>
        <h4>Live number pool</h4>
        <p>Numbers are pulled from an active provider network, refreshed continuously across countries and services.</p>
      </div>
      <div class="feature reveal reveal-delay-1">
        <div class="icon">&#9993;</div>
        <h4>Temporary mail</h4>
        <p>Generate disposable inboxes on your own domain in one click — read messages right in your dashboard.</p>
      </div>
      <div class="feature reveal reveal-delay-2">
        <div class="icon">&#9672;</div>
        <h4>Wallet &amp; history</h4>
        <p>Every request, credit and OTP is logged — a full ledger of your account's activity, always visible.</p>
      </div>
      <div class="feature reveal">
        <div class="icon">&#11041;</div>
        <h4>Fast delivery</h4>
        <p>Check for a new OTP on demand — most codes are ready within moments of the number being used.</p>
      </div>
      <div class="feature reveal reveal-delay-1">
        <div class="icon">&#9858;</div>
        <h4>Secure by design</h4>
        <p>Passwords are hashed, sessions are hardened, and your credentials are never exposed client-side.</p>
      </div>
      <div class="feature reveal reveal-delay-2">
        <div class="icon">&#9678;</div>
        <h4>Simple pricing</h4>
        <p>One transparent rate per number — no subscriptions, no hidden fees, pay only for what you use.</p>
      </div>
    </div>
  </div>
</section>

<section class="section" id="pricing">
  <div class="wrap">
    <div class="section-head reveal">
      <div class="eyebrow" style="justify-content:center;">Pricing</div>
      <h2 class="section-title thread">Pay per number, nothing else</h2>
    </div>
    <div class="grid grid-3">
      <div class="card reveal" style="text-align:center;">
        <h3>Per number</h3>
        <div class="stat gold">Rs <?= number_format($price, 2) ?></div>
      </div>
      <div class="card reveal reveal-delay-1" style="text-align:center;">
        <h3>Temporary mail</h3>
        <div class="stat gold">Free</div>
      </div>
      <div class="card reveal reveal-delay-2" style="text-align:center;">
        <h3>Setup fee</h3>
        <div class="stat gold">Rs 0</div>
      </div>
    </div>
  </div>
</section>

<section class="cta-band">
  <div class="wrap reveal">
    <h2>Ready when you are.</h2>
    <p>Create your account and request your first number in under a minute.</p>
    <a href="<?php echo $user ? 'dashboard.php' : 'auth/register.php'; ?>" class="btn">Get started free</a>
  </div>
</section>

<footer class="site-footer">
  <div class="wrap">
    <div><?= clean($siteName) ?> &copy; <?= date('Y') ?></div>
    <div style="display:flex; gap:20px;">
      <a href="#how-it-works">How it works</a>
      <a href="#features">Features</a>
      <a href="auth/login.php">Log in</a>
    </div>
  </div>
</footer>

<script src="assets/js/animate.js"></script>
</body>
</html>
