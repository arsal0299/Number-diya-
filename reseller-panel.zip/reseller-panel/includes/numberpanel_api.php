<?php
require_once __DIR__ . '/db.php';

/**
 * Calls the Number Panel API (numberpanel.tech) using the master API key
 * stored in the settings table. Users never see or touch this key directly —
 * the site resells access to it via wallet credits.
 */
function np_call(string $method, string $endpoint, array $params = []): array {
    $baseUrl = rtrim(get_setting('np_base_url', 'https://numberpanel.tech'), '/');
    $apiKey  = get_setting('np_api_key', '');

    $url = $baseUrl . $endpoint;
    $ch = curl_init();

    if (strtoupper($method) === 'GET') {
        if (!empty($params)) $url .= '?' . http_build_query($params);
        curl_setopt($ch, CURLOPT_URL, $url);
    } else {
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
    }

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $apiKey,
        'Content-Type: application/json',
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error    = curl_error($ch);
    curl_close($ch);

    if ($response === false) {
        return ['success' => false, 'message' => 'Connection error: ' . $error];
    }

    $data = json_decode($response, true);
    if (!is_array($data)) {
        return ['success' => false, 'message' => 'Invalid response from provider', 'http_code' => $httpCode];
    }
    return $data;
}

function np_services(): array {
    return np_call('GET', '/api/services');
}

function np_countries(string $service): array {
    return np_call('GET', '/api/countries', ['service' => $service]);
}

function np_request_number(string $service, string $country): array {
    return np_call('POST', '/api/request_number', ['service' => $service, 'country' => $country]);
}

function np_release_number(string $number): array {
    return np_call('POST', '/api/release_number', ['number' => $number]);
}

function np_latest_otp(string $number): array {
    return np_call('GET', '/api/latest_otp', ['number' => $number]);
}

function np_mail_domains(): array {
    return np_call('GET', '/api/mail/domains');
}

function np_mail_generate(string $username = '', string $domain = ''): array {
    $params = [];
    if ($username !== '') $params['username'] = $username;
    if ($domain !== '') $params['domain'] = $domain;
    return np_call('POST', '/api/mail/generate', $params);
}

function np_mail_messages(string $address): array {
    return np_call('GET', '/api/mail/messages', ['address' => $address]);
}
