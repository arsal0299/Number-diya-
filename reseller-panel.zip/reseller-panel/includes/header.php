<?php
// Expects $user (array|null) and optional $pageTitle / $pageDescription to be set by the including page.
$siteName = get_setting('site_name', 'Numera');
$title = $pageTitle ?? $siteName;
$description = $pageDescription ?? 'Instant virtual numbers, OTP verification and temporary mail — a premium reseller platform.';
$inAuthDir = strpos($_SERVER['PHP_SELF'], '/auth/') !== false;
$base = $inAuthDir ? '../' : '';
$logo = site_logo_url($base);
$contactEmail = get_setting('contact_email', 'marslan0299@gmail.com');
$currentFile = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= clean($title) ?><?= $title !== $siteName ? ' — ' . clean($siteName) : '' ?></title>
<meta name="description" content="<?= clean($description) ?>">
<meta name="robots" content="<?= empty($user) ? 'index, follow' : 'noindex, nofollow' ?>">
<meta property="og:title" content="<?= clean($title) ?>">
<meta property="og:description" content="<?= clean($description) ?>">
<meta property="og:type" content="website">
<meta name="theme-color" content="#0A0E17">
<link rel="icon" href="<?= $base ?>assets/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="<?= $base ?>assets/css/style.css">
</head>
<body>

<div class="topbar">
  <div class="topbar-inner">
    <div class="topbar-left">
      <?php if (!empty($user)): ?>
      <button class="sidebar-toggle" id="sidebarToggle" aria-label="Open menu">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="4" y1="7" x2="20" y2="7"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="17" x2="20" y2="17"/></svg>
      </button>
      <?php endif; ?>
      <div class="brand">
        <?php if ($logo): ?><img src="<?= clean($logo) ?>" alt="<?= clean($siteName) ?>" class="logo-img">
        <?php else: ?><span class="dot"></span><?= clean($siteName) ?><?php endif; ?>
      </div>
    </div>
    <?php if (!empty($user)): ?>
      <span class="wallet-chip">Rs <?= number_format(wallet_available($user), 2) ?></span>
    <?php endif; ?>
  </div>
</div>

<?php if (!empty($user)): ?>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-head">
    <div class="brand" style="font-size:1.1rem;">
      <?php if ($logo): ?><img src="<?= clean($logo) ?>" alt="<?= clean($siteName) ?>" class="logo-img">
      <?php else: ?><span class="dot"></span><?= clean($siteName) ?><?php endif; ?>
    </div>
    <button class="sidebar-close" id="sidebarClose" aria-label="Close menu">&times;</button>
  </div>
  <div class="sidebar-wallet">
    <div class="amt">Rs <?= number_format(wallet_available($user), 2) ?></div>
    <div class="lbl">Available balance</div>
  </div>
  <nav class="sidebar-body">
    <a class="sidebar-link <?= $currentFile === 'dashboard.php' ? 'active' : '' ?>" href="<?= $base ?>dashboard.php">Numbers</a>
    <a class="sidebar-link <?= $currentFile === 'mail.php' ? 'active' : '' ?>" href="<?= $base ?>mail.php">Temp Mail</a>
    <a class="sidebar-link <?= $currentFile === 'topup.php' ? 'active' : '' ?>" href="<?= $base ?>topup.php">Top Up</a>
    <a class="sidebar-link <?= $currentFile === 'history.php' ? 'active' : '' ?>" href="<?= $base ?>history.php">History</a>
  </nav>
  <div class="sidebar-foot">
    <a class="sidebar-help" href="mailto:<?= clean($contactEmail) ?>">Need help? Contact support</a>
    <a href="<?= $inAuthDir ? 'logout.php' : 'auth/logout.php' ?>" class="btn btn-sm btn-outline" style="margin-top:0; width:100%; text-align:center;">Log out</a>
  </div>
</aside>
<?php endif; ?>

<div class="wrap page">
<?php $flash = get_flash(); if ($flash): ?>
  <div class="alert <?= clean($flash['type']) ?>"><?= clean($flash['message']) ?></div>
<?php endif; ?>
