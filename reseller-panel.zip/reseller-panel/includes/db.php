<?php
require_once __DIR__ . '/../config.php';

function db(): mysqli {
    static $conn = null;
    if ($conn === null) {
        $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if (!$conn) {
            error_log('DB connection failed: ' . mysqli_connect_error());
            show_setup_error('Could not connect to the database.', mysqli_connect_error());
        }
        mysqli_set_charset($conn, 'utf8mb4');
    }
    return $conn;
}

/**
 * Wraps mysqli_prepare so a missing table / bad SQL never causes a blank
 * white-screen fatal error — instead it shows a clear message pointing to
 * setup-check.php. This is almost always what "site/login not working"
 * turns out to be: schema.sql wasn't fully imported.
 */
function safe_prepare(mysqli $conn, string $sql) {
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt === false) {
        error_log('Query prepare failed: ' . mysqli_error($conn) . ' | SQL: ' . $sql);
        show_setup_error('A database query failed to prepare.', mysqli_error($conn));
    }
    return $stmt;
}

function show_setup_error(string $summary, string $detail): void {
    http_response_code(500);
    $debug = defined('APP_DEBUG') && APP_DEBUG;
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Setup needed</title>
    <style>body{font-family:sans-serif;background:#0B0D10;color:#E6E9ED;padding:60px 20px;text-align:center}
    .box{max-width:520px;margin:0 auto;background:#14171B;border:1px solid #262B31;border-radius:12px;padding:32px}
    a{color:#FF7A26}code{background:#1B1F24;padding:2px 6px;border-radius:4px}</style></head><body>
    <div class="box"><h2>Site setup isn\'t finished yet</h2>
    <p>' . htmlspecialchars($summary) . '</p>
    <p>Run <code>setup-check.php</code> in your browser for a full diagnosis, and make sure <code>schema.sql</code> was fully imported in phpMyAdmin.</p>';
    if ($debug) echo '<p style="color:#FF5C5C;font-family:monospace;font-size:0.85rem;">' . htmlspecialchars($detail) . '</p>';
    echo '</div></body></html>';
    exit;
}

/** Fetch a single setting value from the settings table. */
function get_setting(string $key, string $default = ''): string {
    $conn = db();
    $stmt = safe_prepare($conn, 'SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1');
    mysqli_stmt_bind_param($stmt, 's', $key);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    return $row ? $row['setting_value'] : $default;
}

function set_setting(string $key, string $value): void {
    $conn = db();
    $stmt = safe_prepare($conn, 'INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)
        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)');
    mysqli_stmt_bind_param($stmt, 'ss', $key, $value);
    mysqli_stmt_execute($stmt);
}
