<?php
require_once __DIR__ . '/db.php';

function clean(string $v): string {
    return htmlspecialchars(trim($v), ENT_QUOTES, 'UTF-8');
}

function redirect(string $path): void {
    header('Location: ' . $path);
    exit;
}

function flash(string $type, string $message): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash(): ?array {
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

// ── User auth guards ────────────────────────────────────────────────
function current_user(): ?array {
    if (empty($_SESSION['user_id'])) return null;
    static $user = null;
    if ($user === null) {
        $stmt = safe_prepare(db(), 'SELECT * FROM users WHERE id = ? LIMIT 1');
        mysqli_stmt_bind_param($stmt, 'i', $_SESSION['user_id']);
        mysqli_stmt_execute($stmt);
        $user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt)) ?: null;
    }
    return $user;
}

function require_login(): array {
    $user = current_user();
    if (!$user) redirect('login.php');
    if ($user['status'] === 'blocked') {
        session_destroy();
        redirect('login.php?blocked=1');
    }
    return $user;
}

// ── Admin auth guards ───────────────────────────────────────────────
function current_admin(): ?array {
    if (empty($_SESSION['admin_id'])) return null;
    $stmt = safe_prepare(db(), 'SELECT * FROM admins WHERE id = ? LIMIT 1');
    mysqli_stmt_bind_param($stmt, 'i', $_SESSION['admin_id']);
    mysqli_stmt_execute($stmt);
    return mysqli_fetch_assoc(mysqli_stmt_get_result($stmt)) ?: null;
}

function require_admin(): array {
    $admin = current_admin();
    if (!$admin) redirect('login.php');
    return $admin;
}

// ── Wallet helpers ──────────────────────────────────────────────────
function adjust_wallet(int $userId, float $amount, string $type, string $description): bool {
    $conn = db();
    mysqli_begin_transaction($conn);
    try {
        if ($type === 'debit') {
            $stmt = safe_prepare($conn, 'UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ? AND wallet_balance >= ?');
            mysqli_stmt_bind_param($stmt, 'did', $amount, $userId, $amount);
        } else {
            $stmt = safe_prepare($conn, 'UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?');
            mysqli_stmt_bind_param($stmt, 'di', $amount, $userId);
        }
        mysqli_stmt_execute($stmt);
        if (mysqli_stmt_affected_rows($stmt) === 0) {
            mysqli_rollback($conn);
            return false; // e.g. insufficient balance on debit
        }
        $log = safe_prepare($conn, 'INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)');
        mysqli_stmt_bind_param($log, 'isds', $userId, $type, $amount, $description);
        mysqli_stmt_execute($log);
        mysqli_commit($conn);
        return true;
    } catch (Exception $e) {
        mysqli_rollback($conn);
        error_log('Wallet adjust failed: ' . $e->getMessage());
        return false;
    }
}

// ── CSRF protection ─────────────────────────────────────────────────
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . csrf_token() . '">';
}

/** Call at the top of every POST handler. Redirects back with an error if the token is missing/wrong. */
function csrf_verify(string $redirectTo): void {
    $token = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'] ?? '', is_string($token) ? $token : '')) {
        flash('error', 'Security check failed — please try that again.');
        redirect($redirectTo);
    }
}

// ── Wallet holds (money is reserved, not charged, until an OTP arrives) ──
/** Balance the user can actually spend right now (total minus whatever is on hold). */
function wallet_available(array $user): float {
    return (float) $user['wallet_balance'] - (float) ($user['wallet_hold'] ?? 0);
}

/** Reserve $amount from the user's available balance. Returns false if not enough is available. */
function wallet_hold(int $userId, float $amount): bool {
    $stmt = safe_prepare(db(), 'UPDATE users SET wallet_hold = wallet_hold + ? WHERE id = ? AND (wallet_balance - wallet_hold) >= ?');
    mysqli_stmt_bind_param($stmt, 'did', $amount, $userId, $amount);
    mysqli_stmt_execute($stmt);
    return mysqli_stmt_affected_rows($stmt) > 0;
}

/** Cancel a hold without charging anything (number expired / released before an OTP arrived). */
function wallet_release_hold(int $userId, float $amount): void {
    $stmt = safe_prepare(db(), 'UPDATE users SET wallet_hold = GREATEST(wallet_hold - ?, 0) WHERE id = ?');
    mysqli_stmt_bind_param($stmt, 'di', $amount, $userId);
    mysqli_stmt_execute($stmt);
}

/** Turn a hold into a real charge (OTP arrived) and log the transaction. */
function wallet_finalize_hold(int $userId, float $amount, string $description): bool {
    $conn = db();
    mysqli_begin_transaction($conn);
    try {
        $stmt = safe_prepare($conn, 'UPDATE users SET wallet_balance = wallet_balance - ?, wallet_hold = GREATEST(wallet_hold - ?, 0) WHERE id = ? AND wallet_balance >= ?');
        mysqli_stmt_bind_param($stmt, 'ddid', $amount, $amount, $userId, $amount);
        mysqli_stmt_execute($stmt);
        if (mysqli_stmt_affected_rows($stmt) === 0) {
            mysqli_rollback($conn);
            return false;
        }
        $log = safe_prepare($conn, 'INSERT INTO transactions (user_id, type, amount, description) VALUES (?, "debit", ?, ?)');
        mysqli_stmt_bind_param($log, 'ids', $userId, $amount, $description);
        mysqli_stmt_execute($log);
        mysqli_commit($conn);
        return true;
    } catch (Exception $e) {
        mysqli_rollback($conn);
        error_log('Wallet finalize failed: ' . $e->getMessage());
        return false;
    }
}

/** Numbers that timed out (no OTP within the hold window) — release their hold, no charge. */
function expire_pending_numbers(): void {
    $conn = db();
    $stmt = safe_prepare($conn, "SELECT * FROM number_requests WHERE status = 'pending' AND expires_at IS NOT NULL AND expires_at <= NOW()");
    mysqli_stmt_execute($stmt);
    $rows = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);
    foreach ($rows as $r) {
        if (function_exists('np_release_number')) {
            np_release_number($r['number']);
        }
        wallet_release_hold((int) $r['user_id'], (float) $r['hold_amount']);
        $upd = safe_prepare($conn, "UPDATE number_requests SET status = 'expired', released_at = NOW() WHERE id = ?");
        mysqli_stmt_bind_param($upd, 'i', $r['id']);
        mysqli_stmt_execute($upd);
    }
}

// ── Per-service pricing ─────────────────────────────────────────────
function get_service_price(string $service): float {
    $stmt = safe_prepare(db(), 'SELECT price FROM service_prices WHERE service = ? LIMIT 1');
    mysqli_stmt_bind_param($stmt, 's', $service);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    return $row ? (float) $row['price'] : (float) get_setting('price_per_number', '5.00');
}

function set_service_price(string $service, float $price): void {
    $stmt = safe_prepare(db(), 'INSERT INTO service_prices (service, price) VALUES (?, ?) ON DUPLICATE KEY UPDATE price = VALUES(price)');
    mysqli_stmt_bind_param($stmt, 'sd', $service, $price);
    mysqli_stmt_execute($stmt);
}

function all_service_prices(): array {
    return mysqli_fetch_all(mysqli_query(db(), 'SELECT * FROM service_prices ORDER BY service'), MYSQLI_ASSOC);
}

// ── Login brute-force protection ────────────────────────────────────
function record_login_attempt(string $identifier): void {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $stmt = safe_prepare(db(), 'INSERT INTO login_attempts (identifier, ip) VALUES (?, ?)');
    mysqli_stmt_bind_param($stmt, 'ss', $identifier, $ip);
    mysqli_stmt_execute($stmt);
}

function too_many_login_attempts(string $identifier, int $maxAttempts = 6, int $windowMinutes = 15): bool {
    $stmt = safe_prepare(db(), 'SELECT COUNT(*) c FROM login_attempts WHERE identifier = ? AND attempted_at >= DATE_SUB(NOW(), INTERVAL ? MINUTE)');
    mysqli_stmt_bind_param($stmt, 'si', $identifier, $windowMinutes);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    return ((int) $row['c']) >= $maxAttempts;
}

function clear_login_attempts(string $identifier): void {
    $stmt = safe_prepare(db(), 'DELETE FROM login_attempts WHERE identifier = ?');
    mysqli_stmt_bind_param($stmt, 's', $identifier);
    mysqli_stmt_execute($stmt);
}

// ── Uploads (payment proof screenshots) ─────────────────────────────
/** Validates and stores an uploaded image, returns the relative path or null on failure. */
function save_uploaded_proof(array $file): ?string {
    return save_uploaded_image($file, 'payments');
}

/** Generic image upload handler — validates real mime type, caps size, randomizes filename. */
function save_uploaded_image(array $file, string $subdir): ?string {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return null;
    if ($file['size'] > 5 * 1024 * 1024) return null; // 5MB cap

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/svg+xml' => 'svg'];
    if (!isset($allowed[$mime])) return null;

    $dir = __DIR__ . '/../uploads/' . $subdir;
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $name = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
    if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) return null;
    return 'uploads/' . $subdir . '/' . $name;
}

/** Resolves the site logo: uploaded file takes priority, then an external URL, then null (caller falls back to text brand). */
function site_logo_url(string $base = ''): ?string {
    $uploaded = get_setting('site_logo_path', '');
    if ($uploaded !== '') return $base . $uploaded;
    $url = get_setting('site_logo_url', '');
    return $url !== '' ? $url : null;
}
