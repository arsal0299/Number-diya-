<?php $footerBase = strpos($_SERVER['PHP_SELF'], '/auth/') !== false || strpos($_SERVER['PHP_SELF'], '/comeon/') !== false ? '../' : ''; ?>
</div>
<script src="<?= $footerBase ?>assets/js/animate.js"></script>
</body>
</html>
