# Numera — Reseller Panel Setup Guide (v2, premium)

`numberpanel.tech` ke API se virtual numbers, OTP, aur temporary email
resell karne ka platform. Users login karke wallet balance se numbers
request karte hain; admin credits manually add karta hai.

**v2 mein kya naya hai:**
- Poora design luxury/premium theme mein redo — navy + gold palette,
  Playfair Display + Inter fonts, scroll animations, animated homepage.
- Login/site "kaam nahi kar raha" wale bug ka fix (neeche section 5 dekho).
- SEO: meta tags, sitemap.xml, robots.txt, real marketing homepage.

## 1. InfinityFree pe upload

1. InfinityFree account bana lo → naya website add karo (subdomain ya apna domain).
2. Control panel se **File Manager** ya **FTP** (FileZilla) kholo.
3. Is poore folder ka content `htdocs/` mein upload kar do (root mein — `config.php`, `index.php`, `dashboard.php` sab seedhe `htdocs/` ke andar).

## 2. Database banana

1. InfinityFree control panel → **MySQL Databases** → naya database banao.
   Ye tumhe deta hai: hostname (e.g. `sql200.infinityfree.com`), DB name, username, password.
2. **phpMyAdmin** kholo (control panel se link milega), apna database select karo,
   **Import** tab mein `schema.sql` upload kar do. Ye sab tables + default settings bana dega.
   > v2 ka schema.sql **foreign keys use nahi karta** — InfinityFree ke free MySQL plan pe
   > foreign key constraints kabhi kabhi silently table creation fail kar dete hain, jo
   > pichli site ke "login nahi chal raha" issue ki sabse badi wajah thi.

## 3. config.php edit karo

Tumhari DB details (jo tumne bheji thi) already daal di gayi hain is file mein. Sirf
`SITE_URL` ko apne asli domain se replace karo:

```php
define('SITE_URL', 'https://yourdomain.infinityfreeapp.com');
```

## 4. Admin panel login

- URL: `https://yourdomain.com/comeon/`
- Username: `arslan0299`
- Password: `trytohackme`

**Pehla kaam:** login karte hi Settings page (`/comeon/settings.php`) pe jao aur:
1. Apni **Number Panel API key** paste karo (jo tumhe numberpanel.tech ke API Key page se mili).
2. **Price per number** set karo.
3. Phir Settings page se hi apna admin **password change** kar lo.

`/admin` pe koi page nahi khulega — sirf `/comeon` route kaam karega.

## 5. Agar site/login phir bhi "kaam nahi kar raha" lage

Browser mein `https://yourdomain.com/setup-check.php` kholo — ye batayega
exactly kya missing hai (DB connection, tables, admin account, API key)
red/green checklist ke saath. Sab kuch green hone ke baad ye file delete
kar dena (security ke liye).

Agar wahan koi table missing dikhe, phpMyAdmin mein wapas jao aur
`schema.sql` dobara import karo — purani schema se import ho chuki
partial tables ko pehle **drop** kar dena, phir naya schema.sql import karna.

## 6. SEO files

`robots.txt` aur `sitemap.xml` mein `SITE_URL_PLACEHOLDER` ko apne asli
domain se replace kar dena (find & replace) upload karne se pehle.

## 7. Users ke liye flow

1. User `/auth/register.php` se account banata hai (wallet balance 0 se start).
2. Admin `/comeon/users.php` se us user ko credits add karta hai (manual).
3. User login karke `/dashboard.php` pe service + country choose karke number request karta hai,
   uska cost wallet se cut ho jata hai, phir "Check OTP" button se OTP dekh sakta hai.
4. `/mail.php` se temporary email bhi generate kar sakta hai.
5. `/history.php` pe apni saari transactions aur past numbers dekh sakta hai.
6. Homepage (`/`) ab ek public marketing page hai (login zaroori nahi) — SEO ke liye search
   engines isay index kar sakte hain.

## Design notes

- Fonts Google Fonts CDN se load hoti hain (Playfair Display, Inter, JetBrains Mono) —
  ye sirf ek `<link>` tag hai, InfinityFree pe koi extra setup nahi chahiye.
- Animations vanilla JavaScript (`assets/js/animate.js`) se hain — koi bhari library
  (React/Vue/GSAP) nahi use ki, taake shared hosting pe pages fast load hon.
- Agar future mein aur bhi heavy interactivity chahiye ho (real-time OTP push waghera),
  us waqt sochna padega — abhi PHP + vanilla JS hi InfinityFree ke liye sahi choice hai.

## Security notes

- `config.php` aur `includes/` folder `.htaccess` se protected hain (direct browser access blocked).
- API key sirf server-side (`settings` table) mein store hoti hai, kabhi user ko nahi dikhti.
- Passwords bcrypt se hashed store hote hain.
- `setup-check.php` ko live site pe hamesha ke liye mat chhodna — verify karne ke baad delete kar do.
- Automatic payment gateway (JazzCash/EasyPaisa/Stripe) abhi implement nahi — credits admin
  manually add karta hai, jaisa decide hua tha.

## v5 changes (this update)

1. **Sidebar navigation** — top nav (Numbers/Temp Mail/Top Up/History) purani jagah dropdown
   ki tarah tha, ab ek proper slide-in sidebar hai. Hamburger icon (☰) click karo, sidebar
   khulega (overlay ke saath), aur andar close (×) button bhi hai. Isi pattern se admin
   panel ka nav bhi rebuild kiya gaya hai.
2. **Need Help button** — ek hi jagah, sidebar ke neeche, properly designed button —
   `mailto:` link jo Settings → Support contact email se aata hai. Kahin aur email nahi.
3. **Minimum top-up Rs 50** — Settings → "Minimum top-up amount" se change kar sakte ho.
   Isse kam amount ka payment request submit hi nahi hoga (server-side validation).
4. **Logo branding** — Settings → Branding card se logo upload karo (JPG/PNG/WEBP/SVG) ya
   ek URL paste karo. Jahan bhi site name text dikhta tha, ab wahan logo dikhega.
5. **20-minute countdown** — ye pehle se implemented tha (v3/v4): jab number request hota
   hai, uska price sirf "hold" hota hai, charge nahi. Dashboard pe live countdown dikhta
   hai; agar OTP na aaye to number apne aap release ho jata hai aur poora hold refund ho
   jata hai — isko `expire_pending_numbers()` har dashboard load pe check karta hai, aur
   `cron/expire_numbers.php` bhi hai agar koi user site na khole tab bhi refund ho.
6. **Mobile/responsive pass** — sidebar decluttering se topbar overflow issue fix ho gaya;
   tables horizontally scroll karte hain chhoti screens pe, forms/cards stack properly.

### Deploy karne ka tareeqa (agar site already live hai)

1. `schema_update_v4.sql` ko phpMyAdmin mein import karo (naye settings add karta hai,
   koi data delete nahi karta).
2. Poore folder ka content dobara InfinityFree pe upload kar do (purani files overwrite
   ho jayengi).
3. `/comeon/settings.php` pe jao — logo upload karo, minimum top-up confirm karo.
