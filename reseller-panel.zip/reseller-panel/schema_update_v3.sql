-- Number Panel Reseller — v3 migration
-- Run this in phpMyAdmin AFTER your existing schema.sql is already imported.
-- It only ADDS things — safe to run even if the site is already live.
-- If any single line errors with "Duplicate column" or "already exists",
-- that just means it was already applied — skip that line and continue
-- with the rest (run them one at a time if phpMyAdmin stops on the first error).

-- 1. Wallet holds — money is "held" when a number is requested and only
--    actually deducted once an OTP arrives. If it times out, the hold is
--    released and nothing is charged.
ALTER TABLE users ADD COLUMN wallet_hold DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER wallet_balance;

-- 2. number_requests: add pending/expired states + hold tracking + expiry timer
ALTER TABLE number_requests MODIFY status ENUM('pending','active','released','expired') NOT NULL DEFAULT 'pending';
ALTER TABLE number_requests ADD COLUMN hold_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER cost;
ALTER TABLE number_requests ADD COLUMN expires_at DATETIME DEFAULT NULL AFTER requested_at;
ALTER TABLE number_requests ADD COLUMN otp_received_at DATETIME DEFAULT NULL AFTER otp_code;

-- 3. Per-service pricing (admin can override the global price per app)
CREATE TABLE IF NOT EXISTS service_prices (
    service VARCHAR(100) PRIMARY KEY,
    price DECIMAL(10,2) NOT NULL
) ENGINE=InnoDB;

-- 4. Manual payment / top-up requests (bank/JazzCash/Easypaisa proof uploads)
CREATE TABLE IF NOT EXISTS payment_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    screenshot_path VARCHAR(255) NOT NULL,
    status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    admin_reply VARCHAR(255) DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reviewed_at DATETIME DEFAULT NULL,
    INDEX idx_user (user_id)
) ENGINE=InnoDB;

-- 5. Login brute-force protection (used for both user and admin logins)
CREATE TABLE IF NOT EXISTS login_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    identifier VARCHAR(191) NOT NULL,
    ip VARCHAR(45) NOT NULL,
    attempted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_identifier (identifier, attempted_at)
) ENGINE=InnoDB;

-- 6. New settings (all editable from the admin Settings page after this)
INSERT INTO settings (setting_key, setting_value) VALUES
    ('number_hold_minutes', '20'),
    ('country_status', 'Numbers currently working for: USA, UK. Number generation may be temporarily down for other countries — Temp Mail is working fine.'),
    ('contact_email', 'marslan0299@gmail.com'),
    ('payment_method_name', 'Bank Transfer'),
    ('payment_account_title', ''),
    ('payment_account_number', ''),
    ('payment_bank_name', ''),
    ('payment_instructions', 'Send the exact amount to the account above, then upload your payment screenshot below. Your wallet will be credited after admin review.'),
    ('cron_secret', 'change-this-secret-key')
ON DUPLICATE KEY UPDATE setting_key = setting_key;
