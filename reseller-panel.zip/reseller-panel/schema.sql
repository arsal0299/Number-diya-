-- Number Panel Reseller — Database Schema (v2, InfinityFree-safe)
-- Import this in phpMyAdmin. Foreign keys are intentionally NOT used —
-- InfinityFree's free MySQL plan frequently rejects FOREIGN KEY constraints,
-- which silently breaks CREATE TABLE and is the #1 cause of "login doesn't
-- work" (the settings/users tables never actually get created).
-- Indexes are used instead to keep lookups fast without needing FK privileges.

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    wallet_balance DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    status ENUM('active','blocked') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS settings (
    setting_key VARCHAR(50) PRIMARY KEY,
    setting_value TEXT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type ENUM('credit','debit') NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    description VARCHAR(255),
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS number_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    service VARCHAR(100) NOT NULL,
    country VARCHAR(100) NOT NULL,
    number VARCHAR(50) NOT NULL,
    otp_code VARCHAR(20) DEFAULT NULL,
    status ENUM('active','released') NOT NULL DEFAULT 'active',
    cost DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    released_at DATETIME DEFAULT NULL,
    INDEX idx_user (user_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS mailboxes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    address VARCHAR(150) NOT NULL,
    token VARCHAR(255) DEFAULT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id)
) ENGINE=InnoDB;

-- Default settings (edit price + API key from the admin panel after install)
INSERT INTO settings (setting_key, setting_value) VALUES
    ('np_api_key', 'PUT_YOUR_NUMBERPANEL_API_KEY_HERE'),
    ('np_base_url', 'https://numberpanel.tech'),
    ('price_per_number', '5.00'),
    ('site_name', 'Numera'),
    ('min_topup_amount', '50'),
    ('number_hold_minutes', '20')
ON DUPLICATE KEY UPDATE setting_key = setting_key;

-- Default admin login: username "arslan0299", password "trytohackme"
-- Change this password from the admin panel (Settings) right after your first login.
INSERT INTO admins (username, password_hash) VALUES
    ('arslan0299', '$2b$12$pUptSuIZAWxurn2c4vqpKuB4yo8iosY7LAbMKH5.CEmgVe.N2Xa72')
ON DUPLICATE KEY UPDATE username = username;
