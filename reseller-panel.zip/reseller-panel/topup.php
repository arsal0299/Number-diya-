<?php
require_once __DIR__ . '/includes/functions.php';
$user = require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'submit_payment') {
    csrf_verify('topup.php');
    $amount = (float) ($_POST['amount'] ?? 0);
    $minTopup = (float) get_setting('min_topup_amount', '50');

    if ($amount <= 0) {
        flash('error', 'Enter a valid amount.');
    } elseif ($amount < $minTopup) {
        flash('error', 'Minimum top-up is Rs ' . number_format($minTopup, 0) . '. Payments below this can\'t be added.');
    } elseif (empty($_FILES['screenshot']['name'])) {
        flash('error', 'Please upload your payment screenshot.');
    } else {
        $path = save_uploaded_proof($_FILES['screenshot']);
        if (!$path) {
            flash('error', 'Screenshot must be JPG, PNG or WEBP and under 5MB.');
        } else {
            $stmt = safe_prepare(db(), 'INSERT INTO payment_requests (user_id, amount, screenshot_path) VALUES (?, ?, ?)');
            mysqli_stmt_bind_param($stmt, 'ids', $user['id'], $amount, $path);
            mysqli_stmt_execute($stmt);
            flash('success', 'Payment submitted — an admin will review it shortly and your wallet will be credited once approved.');
        }
    }
    redirect('topup.php');
}

$stmt = safe_prepare(db(), 'SELECT * FROM payment_requests WHERE user_id = ? ORDER BY created_at DESC LIMIT 20');
mysqli_stmt_bind_param($stmt, 'i', $user['id']);
mysqli_stmt_execute($stmt);
$myPayments = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);

$methodName = get_setting('payment_method_name', 'Bank Transfer');
$accTitle   = get_setting('payment_account_title', '');
$accNumber  = get_setting('payment_account_number', '');
$bankName   = get_setting('payment_bank_name', '');
$instructions = get_setting('payment_instructions', '');

$pageTitle = 'Add Funds — Top Up';
require_once __DIR__ . '/includes/header.php';
?>
<div class="page-head">
  <h1>Add funds</h1>
  <p>Send payment to the account below, then submit your screenshot as proof.</p>
</div>

<div class="grid grid-2">
  <div class="card">
    <h3>Payment details</h3>
    <div class="feed">
      <div class="feed-row">Method — <strong style="color:var(--text)"><?= clean($methodName) ?></strong></div>
      <?php if ($bankName !== ''): ?><div class="feed-row">Bank — <span class="mono"><?= clean($bankName) ?></span></div><?php endif; ?>
      <?php if ($accTitle !== ''): ?><div class="feed-row">Account title — <span class="mono"><?= clean($accTitle) ?></span></div><?php endif; ?>
      <?php if ($accNumber !== ''): ?><div class="feed-row">Account / number — <span class="mono"><?= clean($accNumber) ?></span></div><?php endif; ?>
    </div>
    <?php if ($instructions !== ''): ?><p style="color:var(--text-dim); font-size:0.88rem; margin-top:16px;"><?= clean($instructions) ?></p><?php endif; ?>
    <?php if ($accNumber === ''): ?><p class="empty">Payment details haven't been set up yet — contact support.</p><?php endif; ?>
  </div>

  <div class="card">
    <h3>Submit payment proof</h3>
    <form method="post" enctype="multipart/form-data">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="submit_payment">
      <label>Amount sent (Rs) — minimum Rs <?= number_format((float) get_setting('min_topup_amount', '50'), 0) ?></label>
      <input type="number" step="0.01" min="<?= number_format((float) get_setting('min_topup_amount', '50'), 2, '.', '') ?>" name="amount" required>
      <label>Payment screenshot</label>
      <input type="file" name="screenshot" accept="image/png,image/jpeg,image/webp" required>
      <button type="submit">Submit for review</button>
    </form>
  </div>
</div>

<div class="page-head" style="margin-top:32px;"><h1>Your payment history</h1></div>
<div class="card table-scroll">
  <?php if (empty($myPayments)): ?>
    <div class="empty">No payment requests yet.</div>
  <?php else: ?>
  <table>
    <tr><th>Amount</th><th>Status</th><th>Admin note</th><th>Submitted</th></tr>
    <?php foreach ($myPayments as $p): ?>
    <tr>
      <td class="mono">Rs <?= number_format((float)$p['amount'], 2) ?></td>
      <td><span class="badge <?= $p['status'] === 'approved' ? 'active' : ($p['status'] === 'rejected' ? 'released' : 'pending') ?>"><?= clean(ucfirst($p['status'])) ?></span></td>
      <td><?= $p['admin_reply'] ? clean($p['admin_reply']) : '—' ?></td>
      <td><?= clean(date('d M, H:i', strtotime($p['created_at']))) ?></td>
    </tr>
    <?php endforeach; ?>
  </table>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
