<?php
/**
 * Visit this file in your browser (yourdomain.com/setup-check.php) any time
 * the site "isn't working" — it tells you exactly what's missing instead of
 * a blank page. Delete this file once everything shows green on a live site.
 */
require_once __DIR__ . '/config.php';

function check_row(string $label, bool $ok, string $detail = ''): void {
    $color = $ok ? '#3ECF8E' : '#FF5C5C';
    $icon = $ok ? '✓' : '✗';
    echo "<div style='display:flex;gap:12px;padding:10px 0;border-bottom:1px solid #262B31;'>
        <span style='color:{$color};font-weight:700;width:20px;'>{$icon}</span>
        <div><div>{$label}</div>" . ($detail ? "<div style='color:#8B939E;font-size:0.85rem;'>" . htmlspecialchars($detail) . "</div>" : "") . "</div>
    </div>";
}
?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Setup Check</title>
<style>body{font-family:sans-serif;background:#0B0D10;color:#E6E9ED;padding:40px 20px;}
.box{max-width:640px;margin:0 auto;background:#14171B;border:1px solid #262B31;border-radius:12px;padding:32px;}
h1{margin-top:0;} h2{font-size:0.95rem;color:#8B939E;text-transform:uppercase;letter-spacing:0.05em;margin:28px 0 8px;}</style>
</head><body><div class="box">
<h1>Setup diagnostic</h1>

<h2>PHP environment</h2>
<?php
check_row('PHP version ' . PHP_VERSION, version_compare(PHP_VERSION, '7.4', '>='), 'Needs 7.4 or higher');
check_row('mysqli extension loaded', extension_loaded('mysqli'));
check_row('curl extension loaded (needed for the Number Panel API)', extension_loaded('curl'));
?>

<h2>Database connection</h2>
<?php
$conn = @mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn) {
    check_row('Connected to database "' . DB_NAME . '" on ' . DB_HOST, true);
} else {
    check_row('Could not connect to database', false, mysqli_connect_error());
}
?>

<h2>Required tables</h2>
<?php
if ($conn) {
    foreach (['users', 'admins', 'settings', 'transactions', 'number_requests', 'mailboxes'] as $table) {
        $res = mysqli_query($conn, "SHOW TABLES LIKE '{$table}'");
        check_row("Table `{$table}` exists", $res && mysqli_num_rows($res) > 0,
            $res && mysqli_num_rows($res) > 0 ? '' : 'Run schema.sql in phpMyAdmin → Import');
    }

    $adminCheck = mysqli_query($conn, "SHOW TABLES LIKE 'admins'");
    if ($adminCheck && mysqli_num_rows($adminCheck) > 0) {
        $adminRow = mysqli_query($conn, "SELECT COUNT(*) c FROM admins");
        $count = $adminRow ? mysqli_fetch_assoc($adminRow)['c'] : 0;
        check_row('At least one admin account exists', $count > 0, $count > 0 ? "{$count} admin(s) found" : 'schema.sql should have inserted "arslan0299" — re-import it');
    }

    $settingsCheck = mysqli_query($conn, "SHOW TABLES LIKE 'settings'");
    if ($settingsCheck && mysqli_num_rows($settingsCheck) > 0) {
        $apiKeyRow = mysqli_query($conn, "SELECT setting_value FROM settings WHERE setting_key='np_api_key'");
        $apiKey = $apiKeyRow ? (mysqli_fetch_assoc($apiKeyRow)['setting_value'] ?? '') : '';
        $keySet = $apiKey && $apiKey !== 'PUT_YOUR_NUMBERPANEL_API_KEY_HERE';
        check_row('Number Panel API key configured', $keySet, $keySet ? '' : 'Set it from /comeon/settings.php after logging in');
    }
} else {
    echo "<p style='color:#8B939E;'>Fix the database connection above first.</p>";
}
?>

<h2>Next step</h2>
<p style="color:#8B939E;font-size:0.9rem;">
If any row above is red, that's the reason the site "isn't working." Once everything is green,
go to <code>/comeon/</code> (username <code>arslan0299</code>) and set your real API key + price,
then delete this <code>setup-check.php</code> file for security.
</p>
</div></body></html>
