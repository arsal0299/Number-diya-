<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'review_payment') {
    csrf_verify('payments.php');
    $id = (int) ($_POST['id'] ?? 0);
    $decision = ($_POST['decision'] ?? '') === 'approve' ? 'approved' : 'rejected';
    $reply = trim($_POST['admin_reply'] ?? '');

    $stmt = safe_prepare(db(), 'SELECT * FROM payment_requests WHERE id = ? AND status = "pending" LIMIT 1');
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $p = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if ($p) {
        if ($decision === 'approved') {
            adjust_wallet((int) $p['user_id'], (float) $p['amount'], 'credit', 'Top-up approved (payment #' . $p['id'] . ')');
            if ($reply === '') $reply = 'Payment verified and credited to your wallet.';
        } else {
            if ($reply === '') $reply = 'This payment could not be verified. Please contact support if you believe this is an error.';
        }
        $upd = safe_prepare(db(), 'UPDATE payment_requests SET status = ?, admin_reply = ?, reviewed_at = NOW() WHERE id = ?');
        mysqli_stmt_bind_param($upd, 'ssi', $decision, $reply, $id);
        mysqli_stmt_execute($upd);
        flash('success', 'Payment ' . $decision . '.');
    }
    redirect('payments.php');
}

$filter = $_GET['status'] ?? 'pending';
$allowed = ['pending', 'approved', 'rejected', 'all'];
if (!in_array($filter, $allowed, true)) $filter = 'pending';

if ($filter === 'all') {
    $payments = mysqli_fetch_all(mysqli_query(db(), 'SELECT pr.*, u.username, u.email FROM payment_requests pr JOIN users u ON u.id = pr.user_id ORDER BY pr.created_at DESC LIMIT 200'), MYSQLI_ASSOC);
} else {
    $stmt = safe_prepare(db(), 'SELECT pr.*, u.username, u.email FROM payment_requests pr JOIN users u ON u.id = pr.user_id WHERE pr.status = ? ORDER BY pr.created_at DESC LIMIT 200');
    mysqli_stmt_bind_param($stmt, 's', $filter);
    mysqli_stmt_execute($stmt);
    $payments = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);
}

$pageTitle = 'Payment Requests';
require_once __DIR__ . '/admin_header.php';
?>
<div class="page-head"><h1>Payment requests</h1><p>Review top-up proofs, approve or reject with a note.</p></div>

<div style="display:flex; gap:10px; margin-bottom:20px; flex-wrap:wrap;">
  <?php foreach (['pending','approved','rejected','all'] as $f): ?>
    <a class="btn btn-sm <?= $filter === $f ? '' : 'btn-outline' ?>" href="payments.php?status=<?= $f ?>"><?= ucfirst($f) ?></a>
  <?php endforeach; ?>
</div>

<div class="card table-scroll">
  <?php if (empty($payments)): ?>
    <div class="empty">No payment requests here.</div>
  <?php else: ?>
  <table>
    <tr><th>User</th><th>Amount</th><th>Proof</th><th>Status</th><th>Note</th><th>Submitted</th><th></th></tr>
    <?php foreach ($payments as $p): ?>
    <tr>
      <td><?= clean($p['username']) ?><br><span style="color:var(--text-dim); font-size:0.78rem;"><?= clean($p['email']) ?></span></td>
      <td class="mono">Rs <?= number_format((float)$p['amount'], 2) ?></td>
      <td><a href="../<?= clean($p['screenshot_path']) ?>" target="_blank" class="btn btn-outline btn-sm">View screenshot</a></td>
      <td><span class="badge <?= $p['status'] === 'approved' ? 'active' : ($p['status'] === 'rejected' ? 'released' : 'pending') ?>"><?= clean(ucfirst($p['status'])) ?></span></td>
      <td style="max-width:220px;"><?= $p['admin_reply'] ? clean($p['admin_reply']) : '—' ?></td>
      <td><?= clean(date('d M, H:i', strtotime($p['created_at']))) ?></td>
      <td>
        <?php if ($p['status'] === 'pending'): ?>
        <details>
          <summary style="cursor:pointer; color:var(--gold); font-size:0.85rem;">Review</summary>
          <div style="margin-top:10px; display:flex; flex-direction:column; gap:8px; min-width:220px;">
            <form method="post">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="review_payment">
              <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
              <textarea name="admin_reply" placeholder="Optional note to the user (e.g. why it was rejected)" style="width:100%; background:var(--panel-raised); border:1px solid var(--line); border-radius:8px; padding:8px; color:var(--text); font-family:var(--font-ui); font-size:0.85rem;" rows="2"></textarea>
              <div style="display:flex; gap:6px; margin-top:8px;">
                <button class="btn btn-sm" type="submit" name="decision" value="approve">Approve &amp; credit</button>
                <button class="btn btn-sm btn-danger" type="submit" name="decision" value="reject">Reject</button>
              </div>
            </form>
          </div>
        </details>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
  </table>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
