<?php
require_once __DIR__ . '/../includes/functions.php';
redirect(current_admin() ? 'dashboard.php' : 'login.php');
