<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$userId = (int) ($_GET['id'] ?? 0);
$stmt = safe_prepare(db(), 'SELECT * FROM users WHERE id = ? LIMIT 1');
mysqli_stmt_bind_param($stmt, 'i', $userId);
mysqli_stmt_execute($stmt);
$u = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
if (!$u) { flash('error', 'User not found.'); redirect('users.php'); }

// Per-app (service) breakdown: how many numbers, how many OTPs, per service.
$byApp = mysqli_fetch_all(
    (function () use ($userId) {
        $s = safe_prepare(db(), "SELECT service, COUNT(*) AS total, SUM(status='active') AS otps FROM number_requests WHERE user_id = ? GROUP BY service ORDER BY total DESC");
        mysqli_stmt_bind_param($s, 'i', $userId);
        mysqli_stmt_execute($s);
        return mysqli_stmt_get_result($s);
    })(),
    MYSQLI_ASSOC
);

$recentNumbers = mysqli_fetch_all(
    (function () use ($userId) {
        $s = safe_prepare(db(), 'SELECT * FROM number_requests WHERE user_id = ? ORDER BY requested_at DESC LIMIT 50');
        mysqli_stmt_bind_param($s, 'i', $userId);
        mysqli_stmt_execute($s);
        return mysqli_stmt_get_result($s);
    })(),
    MYSQLI_ASSOC
);

$transactions = mysqli_fetch_all(
    (function () use ($userId) {
        $s = safe_prepare(db(), 'SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50');
        mysqli_stmt_bind_param($s, 'i', $userId);
        mysqli_stmt_execute($s);
        return mysqli_stmt_get_result($s);
    })(),
    MYSQLI_ASSOC
);

$pageTitle = 'User: ' . $u['username'];
require_once __DIR__ . '/admin_header.php';
?>
<div class="page-head"><h1><?= clean($u['username']) ?></h1><p><?= clean($u['email']) ?> · joined <?= clean(date('d M Y', strtotime($u['created_at']))) ?> · <a href="users.php" style="color:var(--gold-bright);">&larr; back to users</a></p></div>

<div class="grid grid-3" style="margin-bottom:32px;">
  <div class="card"><h3>Wallet balance</h3><div class="stat">Rs <?= number_format((float)$u['wallet_balance'], 2) ?></div></div>
  <div class="card"><h3>Currently held</h3><div class="stat amber">Rs <?= number_format((float)($u['wallet_hold'] ?? 0), 2) ?></div></div>
  <div class="card"><h3>Status</h3><div class="stat"><span class="badge <?= $u['status'] === 'active' ? 'active' : 'blocked' ?>"><?= clean($u['status']) ?></span></div></div>
</div>

<div class="page-head"><h1>Numbers by app</h1></div>
<div class="card table-scroll" style="margin-bottom:32px;">
  <?php if (empty($byApp)): ?>
    <div class="empty">No numbers requested yet.</div>
  <?php else: ?>
  <table>
    <tr><th>App / service</th><th>Numbers bought</th><th>OTPs received</th></tr>
    <?php foreach ($byApp as $a): ?>
    <tr><td><?= clean($a['service']) ?></td><td class="mono"><?= (int)$a['total'] ?></td><td class="mono"><?= (int)$a['otps'] ?></td></tr>
    <?php endforeach; ?>
  </table>
  <?php endif; ?>
</div>

<div class="page-head"><h1>Recent number requests</h1></div>
<div class="card table-scroll" style="margin-bottom:32px;">
  <?php if (empty($recentNumbers)): ?>
    <div class="empty">None yet.</div>
  <?php else: ?>
  <table>
    <tr><th>Number</th><th>Service</th><th>Country</th><th>Status</th><th>OTP</th><th>Cost</th><th>Requested</th></tr>
    <?php foreach ($recentNumbers as $n): ?>
    <tr>
      <td class="mono"><?= clean($n['number']) ?></td>
      <td><?= clean($n['service']) ?></td>
      <td><?= clean($n['country']) ?></td>
      <td><span class="badge <?= $n['status'] === 'active' ? 'active' : ($n['status'] === 'pending' ? 'pending' : 'released') ?>"><?= clean($n['status']) ?></span></td>
      <td class="mono"><?= $n['otp_code'] ? clean($n['otp_code']) : '—' ?></td>
      <td class="mono">Rs <?= number_format((float)$n['cost'], 2) ?></td>
      <td><?= clean(date('d M, H:i', strtotime($n['requested_at']))) ?></td>
    </tr>
    <?php endforeach; ?>
  </table>
  <?php endif; ?>
</div>

<div class="page-head"><h1>Wallet transactions</h1></div>
<div class="card table-scroll">
  <?php if (empty($transactions)): ?>
    <div class="empty">None yet.</div>
  <?php else: ?>
  <table>
    <tr><th>Type</th><th>Amount</th><th>Description</th><th>Date</th></tr>
    <?php foreach ($transactions as $t): ?>
    <tr>
      <td><span class="badge <?= $t['type'] === 'credit' ? 'active' : 'released' ?>"><?= clean($t['type']) ?></span></td>
      <td class="mono">Rs <?= number_format((float)$t['amount'], 2) ?></td>
      <td><?= clean($t['description']) ?></td>
      <td><?= clean(date('d M, H:i', strtotime($t['created_at']))) ?></td>
    </tr>
    <?php endforeach; ?>
  </table>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
