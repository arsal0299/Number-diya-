<?php
$siteName = get_setting('site_name', 'Numera');
$logo = site_logo_url('../');
$currentFile = basename($_SERVER['PHP_SELF']);
$pendingCount = (int) mysqli_fetch_assoc(mysqli_query(db(), "SELECT COUNT(*) c FROM payment_requests WHERE status='pending'"))['c'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= clean($pageTitle ?? 'Admin') ?> — <?= clean($siteName) ?></title>
<meta name="robots" content="noindex, nofollow">
<link rel="icon" href="../assets/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="topbar">
  <div class="topbar-inner">
    <div class="topbar-left">
      <button class="sidebar-toggle" id="sidebarToggle" aria-label="Open menu">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="4" y1="7" x2="20" y2="7"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="17" x2="20" y2="17"/></svg>
      </button>
      <div class="brand">
        <?php if ($logo): ?><img src="<?= clean($logo) ?>" alt="<?= clean($siteName) ?>" class="logo-img">
        <?php else: ?><span class="dot"></span><?= clean($siteName) ?> · Admin<?php endif; ?>
      </div>
    </div>
    <?php if ($pendingCount > 0): ?><span class="wallet-chip" style="border-color:var(--crimson); color:var(--crimson);"><?= $pendingCount ?> pending</span><?php endif; ?>
  </div>
</div>

<div class="sidebar-overlay" id="sidebarOverlay"></div>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-head">
    <div class="brand" style="font-size:1.1rem;">
      <?php if ($logo): ?><img src="<?= clean($logo) ?>" alt="<?= clean($siteName) ?>" class="logo-img">
      <?php else: ?><span class="dot"></span><?= clean($siteName) ?><?php endif; ?>
    </div>
    <button class="sidebar-close" id="sidebarClose" aria-label="Close menu">&times;</button>
  </div>
  <nav class="sidebar-body">
    <a class="sidebar-link <?= $currentFile === 'dashboard.php' ? 'active' : '' ?>" href="dashboard.php">Overview</a>
    <a class="sidebar-link <?= $currentFile === 'users.php' ? 'active' : '' ?>" href="users.php">Users</a>
    <a class="sidebar-link <?= $currentFile === 'payments.php' ? 'active' : '' ?>" href="payments.php">
      Payments
      <?php if ($pendingCount > 0): ?><span class="badge pending" style="margin-left:auto;"><?= $pendingCount ?></span><?php endif; ?>
    </a>
    <a class="sidebar-link <?= $currentFile === 'settings.php' ? 'active' : '' ?>" href="settings.php">Settings</a>
  </nav>
  <div class="sidebar-foot">
    <a class="sidebar-help" href="mailto:<?= clean(get_setting('contact_email', 'marslan0299@gmail.com')) ?>">Need help? Contact support</a>
    <a href="logout.php" class="btn btn-sm btn-outline" style="margin-top:0; width:100%; text-align:center;">Log out</a>
  </div>
</aside>

<div class="wrap page">
<?php $flash = get_flash(); if ($flash): ?>
  <div class="alert <?= clean($flash['type']) ?>"><?= clean($flash['message']) ?></div>
<?php endif; ?>
