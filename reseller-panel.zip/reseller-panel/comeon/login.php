<?php
require_once __DIR__ . '/../includes/functions.php';
if (current_admin()) redirect('dashboard.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify('login.php');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $throttleKey = 'admin:' . strtolower($username);

    if (too_many_login_attempts($throttleKey, 5, 15)) {
        flash('error', 'Too many failed attempts. Please wait 15 minutes and try again.');
        redirect('login.php');
    }

    $stmt = safe_prepare(db(), 'SELECT * FROM admins WHERE username = ? LIMIT 1');
    mysqli_stmt_bind_param($stmt, 's', $username);
    mysqli_stmt_execute($stmt);
    $admin = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if (!$admin || !password_verify($password, $admin['password_hash'])) {
        record_login_attempt($throttleKey);
        flash('error', 'Incorrect admin credentials.');
        redirect('login.php');
    }

    clear_login_attempts($throttleKey);
    $_SESSION['admin_id'] = $admin['id'];
    session_regenerate_id(true);
    redirect('dashboard.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Sign In — <?= clean(get_setting('site_name', 'Numera')) ?></title>
<meta name="robots" content="noindex, nofollow">
<link rel="icon" href="../assets/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="wrap page" style="max-width:420px; padding-top:80px;">
<?php $flash = get_flash(); if ($flash): ?>
  <div class="alert <?= clean($flash['type']) ?>"><?= clean($flash['message']) ?></div>
<?php endif; ?>
  <div class="form-box">
    <h2>Admin sign in</h2>
    <p class="sub">Restricted area.</p>
    <form method="post">
      <?= csrf_field() ?>
      <label>Username</label>
      <input type="text" name="username" required autofocus>
      <label>Password</label>
      <input type="password" name="password" required>
      <button type="submit">Sign in</button>
    </form>
  </div>
</div>
</body>
</html>
