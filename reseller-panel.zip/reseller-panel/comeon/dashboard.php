<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$conn = db();
$totalUsers    = mysqli_fetch_assoc(mysqli_query($conn, 'SELECT COUNT(*) c FROM users'))['c'];
$blockedUsers  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM users WHERE status='blocked'"))['c'];
$totalNumbers  = mysqli_fetch_assoc(mysqli_query($conn, 'SELECT COUNT(*) c FROM number_requests'))['c'];
$activeNumbers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM number_requests WHERE status='active'"))['c'];
$totalRevenue  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE type='debit'"))['s'];
$walletsTotal  = mysqli_fetch_assoc(mysqli_query($conn, 'SELECT COALESCE(SUM(wallet_balance),0) s FROM users'))['s'];
$heldTotal     = mysqli_fetch_assoc(mysqli_query($conn, 'SELECT COALESCE(SUM(wallet_hold),0) s FROM users'))['s'];
$pendingNumbers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM number_requests WHERE status='pending'"))['c'];
$pendingPayments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM payment_requests WHERE status='pending'"))['c'];

$recent = mysqli_fetch_all(mysqli_query($conn, 'SELECT nr.*, u.username FROM number_requests nr JOIN users u ON u.id = nr.user_id ORDER BY nr.requested_at DESC LIMIT 10'), MYSQLI_ASSOC);

$pageTitle = 'Admin Overview';
require_once __DIR__ . '/admin_header.php';
?>
<div class="page-head"><h1>Overview</h1><p>Platform stats at a glance.</p></div>

<div class="grid grid-3" style="margin-bottom:32px;">
  <div class="card table-scroll"><h3>Total users</h3><div class="stat"><?= (int)$totalUsers ?></div></div>
  <div class="card table-scroll"><h3>Blocked users</h3><div class="stat"><?= (int)$blockedUsers ?></div></div>
  <div class="card table-scroll"><h3>Active numbers</h3><div class="stat amber"><?= (int)$activeNumbers ?></div></div>
  <div class="card table-scroll"><h3>Numbers issued (all time)</h3><div class="stat"><?= (int)$totalNumbers ?></div></div>
  <div class="card table-scroll"><h3>Revenue collected</h3><div class="stat amber">Rs <?= number_format((float)$totalRevenue, 2) ?></div></div>
  <div class="card table-scroll"><h3>Total in user wallets</h3><div class="stat">Rs <?= number_format((float)$walletsTotal, 2) ?></div></div>
  <div class="card table-scroll"><h3>Held (pending OTPs)</h3><div class="stat amber">Rs <?= number_format((float)$heldTotal, 2) ?> · <?= (int)$pendingNumbers ?> numbers</div></div>
  <div class="card table-scroll"><h3>Payment requests awaiting review</h3><div class="stat <?= $pendingPayments > 0 ? 'amber' : '' ?>"><?= (int)$pendingPayments ?></div><?php if ($pendingPayments > 0): ?><a href="payments.php" class="btn btn-sm btn-outline" style="margin-top:10px;">Review now</a><?php endif; ?></div>
</div>

<div class="page-head"><h1>Recent number requests</h1></div>
<div class="card table-scroll">
  <?php if (empty($recent)): ?>
    <div class="empty">No requests yet.</div>
  <?php else: ?>
  <table>
    <tr><th>User</th><th>Number</th><th>Service</th><th>Country</th><th>Status</th><th>Requested</th></tr>
    <?php foreach ($recent as $r): ?>
    <tr>
      <td><?= clean($r['username']) ?></td>
      <td class="mono"><?= clean($r['number']) ?></td>
      <td><?= clean($r['service']) ?></td>
      <td><?= clean($r['country']) ?></td>
      <td><span class="badge <?= clean($r['status']) ?>"><?= clean($r['status']) ?></span></td>
      <td><?= clean(date('d M, H:i', strtotime($r['requested_at']))) ?></td>
    </tr>
    <?php endforeach; ?>
  </table>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
