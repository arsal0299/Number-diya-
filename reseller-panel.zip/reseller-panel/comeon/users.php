<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

// ── Add/deduct credit ──────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'adjust_credit') {
    csrf_verify('users.php');
    $userId = (int) ($_POST['user_id'] ?? 0);
    $amount = (float) ($_POST['amount'] ?? 0);
    $type   = ($_POST['type'] ?? 'credit') === 'debit' ? 'debit' : 'credit';

    if ($amount <= 0) {
        flash('error', 'Enter a valid amount.');
    } else {
        $ok = adjust_wallet($userId, $amount, $type, 'Manual adjustment by admin');
        flash($ok ? 'success' : 'error', $ok ? 'Wallet updated.' : 'Could not update wallet (insufficient balance?).');
    }
    redirect('users.php');
}

// ── Block/unblock ──────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'toggle_status') {
    csrf_verify('users.php');
    $userId = (int) ($_POST['user_id'] ?? 0);
    $newStatus = ($_POST['new_status'] ?? '') === 'blocked' ? 'blocked' : 'active';
    $stmt = safe_prepare(db(), 'UPDATE users SET status = ? WHERE id = ?');
    mysqli_stmt_bind_param($stmt, 'si', $newStatus, $userId);
    mysqli_stmt_execute($stmt);
    flash('success', 'User status updated.');
    redirect('users.php');
}

$search = trim($_GET['q'] ?? '');
if ($search !== '') {
    $stmt = safe_prepare(db(), "SELECT u.*,
        (SELECT COUNT(*) FROM number_requests nr WHERE nr.user_id = u.id) AS total_numbers,
        (SELECT COUNT(*) FROM number_requests nr WHERE nr.user_id = u.id AND nr.status = 'active') AS otp_count,
        (SELECT COALESCE(SUM(amount),0) FROM transactions t WHERE t.user_id = u.id AND t.type = 'debit') AS total_spent
        FROM users u WHERE u.username LIKE CONCAT('%',?,'%') OR u.email LIKE CONCAT('%',?,'%') ORDER BY u.created_at DESC");
    mysqli_stmt_bind_param($stmt, 'ss', $search, $search);
    mysqli_stmt_execute($stmt);
    $users = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);
} else {
    $users = mysqli_fetch_all(mysqli_query(db(), "SELECT u.*,
        (SELECT COUNT(*) FROM number_requests nr WHERE nr.user_id = u.id) AS total_numbers,
        (SELECT COUNT(*) FROM number_requests nr WHERE nr.user_id = u.id AND nr.status = 'active') AS otp_count,
        (SELECT COALESCE(SUM(amount),0) FROM transactions t WHERE t.user_id = u.id AND t.type = 'debit') AS total_spent
        FROM users u ORDER BY u.created_at DESC"), MYSQLI_ASSOC);
}

$pageTitle = 'Manage Users';
require_once __DIR__ . '/admin_header.php';
?>
<div class="page-head"><h1>Users</h1><p>Add credits, block/unblock accounts, and see who's buying what.</p></div>

<form method="get" style="margin-bottom:20px; max-width:340px;">
  <input type="text" name="q" placeholder="Search username or email…" value="<?= clean($search) ?>">
</form>

<div class="card table-scroll">
  <?php if (empty($users)): ?>
    <div class="empty">No users found.</div>
  <?php else: ?>
  <table>
    <tr><th>Username</th><th>Email</th><th>Wallet</th><th>Held</th><th>Numbers</th><th>OTPs received</th><th>Total spent</th><th>Status</th><th>Joined</th><th>Actions</th></tr>
    <?php foreach ($users as $u): ?>
    <tr>
      <td><a href="user_detail.php?id=<?= (int)$u['id'] ?>" style="color:var(--gold-bright);"><?= clean($u['username']) ?></a></td>
      <td><?= clean($u['email']) ?></td>
      <td class="mono">Rs <?= number_format((float)$u['wallet_balance'], 2) ?></td>
      <td class="mono">Rs <?= number_format((float)($u['wallet_hold'] ?? 0), 2) ?></td>
      <td class="mono"><?= (int)$u['total_numbers'] ?></td>
      <td class="mono"><?= (int)$u['otp_count'] ?></td>
      <td class="mono">Rs <?= number_format((float)$u['total_spent'], 2) ?></td>
      <td><span class="badge <?= $u['status'] === 'active' ? 'active' : 'blocked' ?>"><?= clean($u['status']) ?></span></td>
      <td><?= clean(date('d M Y', strtotime($u['created_at']))) ?></td>
      <td>
        <details>
          <summary style="cursor:pointer; color:var(--gold); font-size:0.85rem;">Manage</summary>
          <div style="margin-top:10px; display:flex; flex-direction:column; gap:8px; min-width:220px;">
            <form method="post" style="display:flex; gap:6px;">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="adjust_credit">
              <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
              <input type="number" step="0.01" name="amount" placeholder="Amount" style="width:90px;" required>
              <select name="type" style="width:90px;">
                <option value="credit">Add</option>
                <option value="debit">Deduct</option>
              </select>
              <button class="btn btn-sm" type="submit">Go</button>
            </form>
            <form method="post">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="toggle_status">
              <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
              <input type="hidden" name="new_status" value="<?= $u['status'] === 'active' ? 'blocked' : 'active' ?>">
              <button class="btn btn-sm <?= $u['status'] === 'active' ? 'btn-danger' : 'btn-outline' ?>" type="submit">
                <?= $u['status'] === 'active' ? 'Block user' : 'Unblock user' ?>
              </button>
            </form>
          </div>
        </details>
      </td>
    </tr>
    <?php endforeach; ?>
  </table>
  <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
