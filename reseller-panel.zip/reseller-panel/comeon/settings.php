<?php
require_once __DIR__ . '/../includes/functions.php';
$admin = require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_settings') {
    csrf_verify('settings.php');
    set_setting('site_name', trim($_POST['site_name'] ?? ''));
    set_setting('np_api_key', trim($_POST['np_api_key'] ?? ''));
    set_setting('np_base_url', trim($_POST['np_base_url'] ?? ''));
    set_setting('price_per_number', (string) max(0, (float) ($_POST['price_per_number'] ?? 0)));
    set_setting('number_hold_minutes', (string) max(1, (int) ($_POST['number_hold_minutes'] ?? 20)));
    set_setting('country_status', trim($_POST['country_status'] ?? ''));
    set_setting('contact_email', trim($_POST['contact_email'] ?? ''));
    set_setting('min_topup_amount', (string) max(0, (float) ($_POST['min_topup_amount'] ?? 50)));
    flash('success', 'Settings saved.');
    redirect('settings.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_branding') {
    csrf_verify('settings.php');
    if (!empty($_FILES['logo_file']['name'])) {
        $path = save_uploaded_image($_FILES['logo_file'], 'branding');
        if ($path) {
            set_setting('site_logo_path', $path);
            set_setting('site_logo_url', '');
        } else {
            flash('error', 'Logo must be JPG, PNG, WEBP or SVG and under 5MB.');
            redirect('settings.php');
        }
    } elseif (trim($_POST['logo_url'] ?? '') !== '') {
        set_setting('site_logo_url', trim($_POST['logo_url']));
        set_setting('site_logo_path', '');
    } elseif (!empty($_POST['clear_logo'])) {
        set_setting('site_logo_path', '');
        set_setting('site_logo_url', '');
    }
    flash('success', 'Branding updated.');
    redirect('settings.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_payment') {
    csrf_verify('settings.php');
    set_setting('payment_method_name', trim($_POST['payment_method_name'] ?? ''));
    set_setting('payment_bank_name', trim($_POST['payment_bank_name'] ?? ''));
    set_setting('payment_account_title', trim($_POST['payment_account_title'] ?? ''));
    set_setting('payment_account_number', trim($_POST['payment_account_number'] ?? ''));
    set_setting('payment_instructions', trim($_POST['payment_instructions'] ?? ''));
    flash('success', 'Payment details saved.');
    redirect('settings.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_cron_secret') {
    csrf_verify('settings.php');
    $secret = trim($_POST['cron_secret'] ?? '');
    if ($secret === '') $secret = bin2hex(random_bytes(12));
    set_setting('cron_secret', $secret);
    flash('success', 'Cron secret saved.');
    redirect('settings.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_service_price') {
    csrf_verify('settings.php');
    $service = trim($_POST['service'] ?? '');
    $price = (float) ($_POST['price'] ?? 0);
    if ($service !== '' && $price >= 0) {
        set_service_price($service, $price);
        flash('success', 'Price saved for ' . $service . '.');
    }
    redirect('settings.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'change_password') {
    csrf_verify('settings.php');
    $current = $_POST['current_password'] ?? '';
    $new     = $_POST['new_password'] ?? '';
    if (!password_verify($current, $admin['password_hash'])) {
        flash('error', 'Current password is incorrect.');
    } elseif (strlen($new) < 8) {
        flash('error', 'New password must be at least 8 characters.');
    } else {
        $hash = password_hash($new, PASSWORD_DEFAULT);
        $stmt = safe_prepare(db(), 'UPDATE admins SET password_hash = ? WHERE id = ?');
        mysqli_stmt_bind_param($stmt, 'si', $hash, $admin['id']);
        mysqli_stmt_execute($stmt);
        flash('success', 'Password changed.');
    }
    redirect('settings.php');
}

$servicePrices = all_service_prices();

$pageTitle = 'Admin Settings';
require_once __DIR__ . '/admin_header.php';
?>
<div class="page-head"><h1>Settings</h1></div>

<div class="grid grid-2">
  <div class="card">
    <h3>Site &amp; API</h3>
    <form method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save_settings">
      <label>Site name</label>
      <input type="text" name="site_name" value="<?= clean(get_setting('site_name', '')) ?>" required>
      <label>Number Panel API key</label>
      <input type="text" name="np_api_key" value="<?= clean(get_setting('np_api_key', '')) ?>" required>
      <label>Number Panel base URL</label>
      <input type="text" name="np_base_url" value="<?= clean(get_setting('np_base_url', 'https://numberpanel.tech')) ?>" required>
      <label>Default price per number (Rs)</label>
      <input type="number" step="0.01" name="price_per_number" value="<?= clean(get_setting('price_per_number', '5.00')) ?>" required>
      <label>Number hold time before auto-refund (minutes)</label>
      <input type="number" min="1" name="number_hold_minutes" value="<?= clean(get_setting('number_hold_minutes', '20')) ?>" required>
      <label>Country / service status banner (shown to users on the dashboard)</label>
      <input type="text" name="country_status" value="<?= clean(get_setting('country_status', '')) ?>" placeholder="e.g. USA, UK working — number generation down elsewhere">
      <label>Support contact email</label>
      <input type="email" name="contact_email" value="<?= clean(get_setting('contact_email', '')) ?>">
      <label>Minimum top-up amount (Rs)</label>
      <input type="number" step="1" min="0" name="min_topup_amount" value="<?= clean(get_setting('min_topup_amount', '50')) ?>" required>
      <button type="submit">Save settings</button>
    </form>
  </div>

  <div class="card">
    <h3>Branding</h3>
    <p style="color:var(--text-dim); font-size:0.85rem; margin-top:-6px;">Upload a logo file, or link one by URL — uploading clears any URL, and vice versa.</p>
    <?php $currentLogo = site_logo_url('../'); ?>
    <?php if ($currentLogo): ?>
      <div style="display:flex; align-items:center; gap:12px; margin:14px 0; padding:10px; background:var(--panel-raised); border-radius:8px;">
        <img src="<?= clean($currentLogo) ?>" alt="Current logo" style="height:32px; width:auto;">
        <span style="color:var(--text-dim); font-size:0.82rem;">Current logo</span>
      </div>
    <?php endif; ?>
    <form method="post" enctype="multipart/form-data">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save_branding">
      <label>Upload logo file</label>
      <input type="file" name="logo_file" accept="image/png,image/jpeg,image/webp,image/svg+xml">
      <label>— or — Logo URL</label>
      <input type="text" name="logo_url" placeholder="https://example.com/logo.svg" value="<?= clean(get_setting('site_logo_url', '')) ?>">
      <button type="submit">Save branding</button>
    </form>
    <?php if ($currentLogo): ?>
    <form method="post" style="margin-top:8px;">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save_branding">
      <input type="hidden" name="clear_logo" value="1">
      <button class="btn btn-outline btn-sm" type="submit" style="margin-top:0;">Remove logo (use site name text instead)</button>
    </form>
    <?php endif; ?>
  </div>

  <div class="card">
    <h3>Payment details (shown on user Top Up page)</h3>
    <form method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save_payment">
      <label>Method name</label>
      <input type="text" name="payment_method_name" value="<?= clean(get_setting('payment_method_name', 'Bank Transfer')) ?>" placeholder="e.g. JazzCash / Easypaisa / Bank Transfer">
      <label>Bank / provider name</label>
      <input type="text" name="payment_bank_name" value="<?= clean(get_setting('payment_bank_name', '')) ?>">
      <label>Account title</label>
      <input type="text" name="payment_account_title" value="<?= clean(get_setting('payment_account_title', '')) ?>">
      <label>Account number</label>
      <input type="text" name="payment_account_number" value="<?= clean(get_setting('payment_account_number', '')) ?>">
      <label>Instructions shown to users</label>
      <input type="text" name="payment_instructions" value="<?= clean(get_setting('payment_instructions', '')) ?>">
      <button type="submit">Save payment details</button>
    </form>
  </div>

  <div class="card">
    <h3>Per-service pricing</h3>
    <p style="color:var(--text-dim); font-size:0.85rem; margin-top:-6px;">Overrides the default price above for a specific app/service.</p>
    <form method="post" style="display:flex; gap:8px; align-items:flex-end; flex-wrap:wrap;">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save_service_price">
      <div><label>Service name</label><input type="text" name="service" placeholder="e.g. WhatsApp" required style="width:160px;"></div>
      <div><label>Price (Rs)</label><input type="number" step="0.01" min="0" name="price" required style="width:110px;"></div>
      <button class="btn btn-sm" type="submit" style="margin-top:0;">Save price</button>
    </form>
    <?php if (!empty($servicePrices)): ?>
    <div class="table-scroll">
    <table style="margin-top:16px;">
      <tr><th>Service</th><th>Price</th></tr>
      <?php foreach ($servicePrices as $sp): ?>
      <tr><td><?= clean($sp['service']) ?></td><td class="mono">Rs <?= number_format((float)$sp['price'], 2) ?></td></tr>
      <?php endforeach; ?>
    </table>
    </div>
    <?php endif; ?>
  </div>

  <div class="card">
    <h3>Cron secret (for auto-refund scheduler)</h3>
    <p style="color:var(--text-dim); font-size:0.85rem; margin-top:-6px;">Used in <span class="mono">/cron/expire_numbers.php?key=...</span> — set a scheduler to hit that URL every few minutes.</p>
    <form method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save_cron_secret">
      <label>Secret key</label>
      <input type="text" name="cron_secret" value="<?= clean(get_setting('cron_secret', '')) ?>">
      <button type="submit">Save</button>
    </form>
  </div>

  <div class="card">
    <h3>Change admin password</h3>
    <form method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="change_password">
      <label>Current password</label>
      <input type="password" name="current_password" required>
      <label>New password</label>
      <input type="password" name="new_password" required minlength="8">
      <button type="submit">Change password</button>
    </form>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
