<?php
require_once __DIR__ . '/../includes/functions.php';
if (current_user()) redirect('../dashboard.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify('register.php');
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (strlen($username) < 3 || !preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        flash('error', 'Username must be 3+ characters, letters/numbers/underscore only.');
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        flash('error', 'Please enter a valid email address.');
    } elseif (strlen($password) < 6) {
        flash('error', 'Password must be at least 6 characters.');
    } else {
        $conn = db();
        $check = safe_prepare($conn, 'SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1');
        mysqli_stmt_bind_param($check, 'ss', $username, $email);
        mysqli_stmt_execute($check);
        if (mysqli_fetch_assoc(mysqli_stmt_get_result($check))) {
            flash('error', 'That username or email is already registered.');
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = safe_prepare($conn, 'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)');
            mysqli_stmt_bind_param($stmt, 'sss', $username, $email, $hash);
            mysqli_stmt_execute($stmt);
            flash('success', 'Account created — please log in.');
            redirect('login.php');
        }
    }
    redirect('register.php');
}

$pageTitle = 'Create account';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="form-box">
  <h2>Create your account</h2>
  <p class="sub">Get a wallet, request numbers, and receive OTPs in seconds.</p>
  <form method="post">
    <?= csrf_field() ?>
    <label>Username</label>
    <input type="text" name="username" required>
    <label>Email</label>
    <input type="email" name="email" required>
    <label>Password</label>
    <input type="password" name="password" required minlength="6">
    <button type="submit">Create account</button>
  </form>
  <p class="sub" style="margin-top:16px;">Already have an account? <a href="login.php" style="color:var(--amber)">Log in</a></p>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
