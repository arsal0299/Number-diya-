<?php
require_once __DIR__ . '/../includes/functions.php';
if (current_user()) redirect('../dashboard.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify('login.php');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $throttleKey = 'user:' . strtolower($username);

    if (too_many_login_attempts($throttleKey)) {
        flash('error', 'Too many failed attempts. Please wait 15 minutes and try again.');
        redirect('login.php');
    }

    $stmt = safe_prepare(db(), 'SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1');
    mysqli_stmt_bind_param($stmt, 'ss', $username, $username);
    mysqli_stmt_execute($stmt);
    $user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if (!$user || !password_verify($password, $user['password_hash'])) {
        record_login_attempt($throttleKey);
        flash('error', 'Incorrect username or password.');
        redirect('login.php');
    }
    if ($user['status'] === 'blocked') {
        flash('error', 'Your account has been blocked. Contact support.');
        redirect('login.php');
    }

    clear_login_attempts($throttleKey);
    $_SESSION['user_id'] = $user['id'];
    session_regenerate_id(true);
    redirect('../dashboard.php');
}

$pageTitle = 'Log in';
require_once __DIR__ . '/../includes/header.php';
?>
<div class="form-box">
  <h2>Log in</h2>
  <p class="sub">Welcome back.</p>
  <?php if (!empty($_GET['blocked'])): ?>
    <div class="alert error">Your account was blocked. Contact support.</div>
  <?php endif; ?>
  <form method="post">
    <?= csrf_field() ?>
    <label>Username or email</label>
    <input type="text" name="username" required>
    <label>Password</label>
    <input type="password" name="password" required>
    <button type="submit">Log in</button>
  </form>
  <p class="sub" style="margin-top:16px;">No account yet? <a href="register.php" style="color:var(--amber)">Create one</a></p>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
