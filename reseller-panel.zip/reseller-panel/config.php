<?php
/**
 * Site configuration.
 */

// ── Database (from InfinityFree control panel) ─────────────────────────
define('DB_HOST', 'sql311.infinityfree.com');
define('DB_NAME', 'if0_42537803_ss');
define('DB_USER', 'if0_42537803');
define('DB_PASS', 'Arslan10299');

// ── Site ─────────────────────────────────────────────────────────────
define('SITE_URL', 'https://yourdomain.infinityfreeapp.com'); // no trailing slash

// ── Debug mode ───────────────────────────────────────────────────────
// Set to true ONLY while troubleshooting on a site your visitors don't use
// yet — it shows real PHP/SQL errors on screen instead of a blank page.
// Set back to false before going live.
define('APP_DEBUG', false);

// Session cookie hardening
ini_set('session.cookie_httponly', 1);
ini_set('session.use_strict_mode', 1);
session_start();

error_reporting(E_ALL);
ini_set('display_errors', APP_DEBUG ? 1 : 0);
